const Discord = require("discord.js");
const client = new Discord.Client();
const ayarlar = require("./ayarlar.json");
const chalk = require("chalk");
const moment = require("moment");
var Jimp = require("jimp");
const { Client, Util } = require("discord.js");
const http = require("http");
const YouTube = require('simple-youtube-api');
const weather = require("weather-js");
const fs = require("fs");
const db = require("quick.db");
require("./util/eventLoader")(client);
const path = require("path");
const request = require("request");
const ytdl = require('ytdl-core');
const express = require("express");
const snekfetch = require("snekfetch");
const queue = new Map();

const TimsahTim = new Discord.WebhookClient("735894420788084758", "_tXtVlKXEvNSxYV4V3OQafZmiio_Yb5tKJNGtSkhpXQgTC2-nv19Qu49z3O3Ls2HkCwT")

const app = express();
app.get("/", (request, response) => {
  //console.log(Date.now() + " BOT Aktif.");
  //response.sendStatus(200);
});
app.listen(process.env.PORT);
setInterval(() => {
  http.get(`http://${process.env.PROJECT_NAME}.glitch.me`);
}, 1000 * 60 * 3);


var prefix = ayarlar.prefix;

const log = message => {
  console.log(`${message}`);
};

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
fs.readdir("./komutlar/", (err, files) => {
  if (err) console.error(err);
  log(`${files.length} komut yüklenecek.`);
  files.forEach(f => {
    let props = require(`./komutlar/${f}`);
    log(`Yüklenen komut: ${props.help.name}.`);
    client.commands.set(props.help.name, props);
    props.conf.aliases.forEach(alias => {
      client.aliases.set(alias, props.help.name);
    });
  });
});

client.reload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./komutlar/${command}`)];
      let cmd = require(`./komutlar/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.load = command => {
  return new Promise((resolve, reject) => {
    try {
      let cmd = require(`./komutlar/${command}`);
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.unload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./komutlar/${command}`)];
      let cmd = require(`./komutlar/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

client.elevation = message => {
  if (!message.guild) {
    return;
  }
  let permlvl = 0;
  if (message.member.hasPermission("BAN_MEMBERS")) permlvl = 2;
  if (message.member.hasPermission("ADMINISTRATOR")) permlvl = 3;
  if (message.author.id === ayarlar.sahip) permlvl = 4;
  return permlvl;
};

var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;
// client.on('debug', e => {
//   console.log(chalk.bgBlue.green(e.replace(regToken, 'that was redacted')));
// });

client.on("warn", e => {
  console.log(chalk.bgYellow(e.replace(regToken, "that was redacted")));
});

client.on("error", e => {
  console.log(chalk.bgRed(e.replace(regToken, "that was redacted")));
});

client.login(ayarlar.token);

client.on("guildCreate", guild => {
  let kanal = guild.channels.filter(c => c.type === "text").random();

  kanal.send(
    "***Beni Sunucunuza Eklediğiniz İçin Teşekkürler !*** ( **Prefixim: -** )"
  );
});

client.on("message", msg => {
  if (msg.content.toLowerCase() === "sa") {
    msg.reply("as");

  }
});

client.on("message", msg => {
  if (msg.content.toLowerCase() === "sea") {
    msg.reply("as");
  
}
});

client.on("message", msg => {
  if (msg.content.toLowerCase() === "selam") {
    msg.reply("Aleyküm Selam");
  
}
});

client.on("message", msg => {
  if (msg.content.toLowerCase() === "günaydın herkese") {
    msg.reply("Sanada Günaydın. :smiling_face_with_3_hearts:");
  
}
});

client.on("message", msg => {
  if (msg.content.toLowerCase() === "günaydın") {
    msg.reply("Sanada Günaydın. :smiling_face_with_3_hearts:");
  
}
});
client.on("message", msg => {
  if (msg.content.toLowerCase() === "Günaydın gençler") {
    msg.reply("Sanada Günaydın. :smiling_face_with_3_hearts:");
  
}
});
client.on("message", msg => {
  if (msg.content.toLowerCase() === "Günaydın") {
    msg.reply("Sanada Günaydın. :smiling_face_with_3_hearts:");
  
}
});

client.on("message", msg => {
  if (msg.content.toLowerCase() === "DangerK") {
    msg.reply("Bekle Birazdan Cevap Verir !");
  
}
});

/////////////////////////////////////////////////////////////////////////////////////////

client.on("message", async message => {
  const ms = require("ms");
  const args = message.content
    .slice(prefix.length)
    .trim()
    .split(/ +/g);
  const command = args.shift().toLowerCase();
  let u = message.mentions.users.first() || message.author;
  if (command === "normal-sunucu-kur") {
    if (
      message.guild.channels.find(channel => channel.name === "Bot Kullanımı")
    )
      return message.channel.send(" Bot Paneli Zaten Ayarlanmış.");
    message.channel.send(
      `Bot Bilgi Kanallarının Kurulumu Başlatılsın Mı? Başlatılacak İse **Kabul** Yazınız !`
    );
    if (!message.member.hasPermission("Yönetici"))
      if (message.author.id !== "456406598961856512")
        return message.channel.send(
          " Bu Kodu `Yapımcım  Olan Kişi Kullanabilir."
        );
    message.channel
      .awaitMessages(response => response.content === "Kabul", {
        max: 1,
        time: 10000,
        errors: ["time"]

     })

       .then(collected => {
        message.guild.createChannel("👋 | HOŞ GELDİNİZ", "category", [
          {
            id: message.guild.id,
            deny: ["SEND_MESSAGES"]
          }
        ]);

        message.guild
          .createChannel("「🚪」gelen-giden", "text", [
            {
              id: message.guild.id,
              deny: ["SEND_MESSAGES"]
            }
          ])
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "👋 | HOŞ GELDİNİZ"
              )
            )
          );
      })
      .then(collected => {
        message.guild.createChannel("📜 | BİLGİLENDİRME", "category", [
          {
            id: message.guild.id
          }
        ]);

        message.guild
          .createChannel("「📋」kurallar", "text", [
            {
              id: message.guild.id,
              deny: ["SEND_MESSAGES"]
            }
          ])
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "📜 | BİLGİLENDİRME"
              )
            )
          );
        message.guild
          .createChannel("「📢」duyurular", "text", [
            {
              id: message.guild.id,
              deny: ["SEND_MESSAGES"]
            }
          ])
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "📜 | BİLGİLENDİRME"
              )
            )
          );
        message.guild
          .createChannel("「💾」log-kanalı", "text", [
            {
              id: message.guild.id,
              deny: ["SEND_MESSAGES"]
            }
          ])       
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "📜 | BİLGİLENDİRME"
              )
            )
          );
      })
      .then(collected => {
        message.guild.createChannel("📝 | METİN KANALLARI", "category", [
          {
            id: message.guild.id
          }
        ]);

        message.guild
          .createChannel(`「💬」genel-sohbet`, "text")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "📝 | METİN KANALLARI"
              )
            )
          );
        message.guild
          .createChannel(`「📷」görsel-içerik`, "text")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "📝 | METİN KANALLARI"
              )
            )
          );
        message.guild
          .createChannel(`「🤖」bot-komutları`, "text")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "📝 | METİN KANALLARI"
              )
            )
          );
      })
      .then(collected => {
        message.guild.createChannel("🏆 | YETKİLİ ODALARI", "category", [
          {
            id: message.guild.id
          }
        ]);
        message.guild
          .createChannel(`「💼」yetkili-sohbet`, "text")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🏆 | YETKİLİ ODALARI"
              )
            )
          );
                 message.guild
          .createChannel(`「🏆」Kurucu`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🏆 | YETKİLİ ODALARI"
              )
            )
          );
              message.guild
          .createChannel(`「👑」Yönetici`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🏆 | YETKİLİ ODALARI"
              )
            )
          );
                 message.guild
          .createChannel(`「🌠」Moderatör`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🏆 | YETKİLİ ODALARI"
              )
            )
          );

        message.guild.createChannel("🔴 | YOUTUBE ODALARI", "category", [
          {
            id: message.guild.id
          }
        ]);

        message.guild
          .createChannel(`「▶」video-duyuru`, "text")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🔴 | YOUTUBE ODALARI"
              )
            )
          );

        message.guild
          .createChannel(`「▶」Video Odası`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🔴 | YOUTUBE ODALARI"
              )
            )
          );

        message.guild.createChannel("💬 | SOHBET ODALARI", "category", [
          {
            id: message.guild.id
          }
        ]);

        message.guild
          .createChannel(`「💬」Sesli Sohbet 1`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "💬 | SOHBET ODALARI"
              )
            )
          );

        message.guild
          .createChannel(`「💬」Sesli Sohbet 2`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "💬 | SOHBET ODALARI"
              )
            )
          );

        message.guild
          .createChannel(`「💬」Sesli Sohbet 3`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "💬 | SOHBET ODALARI"
              )
            )
          );

        message.guild.createChannel("🎶 | MÜZİK ODALARI", "category", [
          {
            id: message.guild.id
          }
        ]);

        message.guild
          .createChannel(`「🎶」Müzik Odası 1`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🎶 | MÜZİK ODALARI"
              )
            )
          );

        message.guild
          .createChannel(`「🎶」Müzik Odası 2`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🎶 | MÜZİK ODALARI"
              )
            )
          );

        message.guild
          .createChannel(`「🎶」Müzik Odası 3`, "voice")
          .then(channel =>
            channel.setParent(
              message.guild.channels.find(
                channel => channel.name === "🎶 | MÜZİK ODALARI"
              )
            )
          );

      

        message.guild.createRole({
          name: "🌟 | Sahip",
          color: "00FFB5",
          permissions: []
        });

        message.guild.createRole({
          name: "👑 | Kurucu",
          color: "00BDFF",
          permissions: []
        });

        message.guild.createRole({
          name: "⭐️ | Yönetici",
          color: "00FF08",
          permissions: [,]
        });

        message.guild.createRole({
          name: "🌠 | Moderator",
          color: "#2E924E",
          permissions: []
        });

        message.guild.createRole({
          name: "⚙️ | Destek Ekibi",
          color: "#FF0000",
          permissions: []
        });

        message.guild.createRole({
          name: "🎥 | YouTube",
          color: "#00FFB6",
          permissions: []
        });

        message.guild.createRole({
          name: "🎥 | Mini YouTube",
          color: "#FF8100",
          permissions: []
        });

        message.guild.createRole({
          name: "⚡️ | Üye",
          color: "#CAF7FC",
          permissions: []
        });

        message.guild.createRole({
          name: "🤖 | Bot",
          color: "#21b81c",
          permissions: []

        });
        message.channel.send("✅ Gerekli Herşey Kuruldu İyi Eğlenceler ! 🎉");
      });
  }
});

/////////////////////////////////////////////////////////////////////////

client.on('guildMemberAdd', async (member, guild, message) => {
 
let role = db.fetch(`otorolisim_${member.guild.id}`)
 let otorol = db.fetch(`autoRole_${member.guild.id}`)
 let i = db.fetch(`otorolKanal_${member.guild.id}`)
 if (!otorol || otorol.toLowerCase() === 'yok') return;
else {
 try {
 
 
  if (!i) return
if (!role) {
  member.addRole(member.guild.roles.get(otorol))
                        var embed = new Discord.RichEmbed()
                        .setDescription("**Sunucuya Yeni Katılan** @" + member.user.tag + " **Kullanıcısına** <@&" + otorol + ">  **Rolü verildi.**")
                        .setColor('0x36393E')
                        .setFooter(`Otorol Sistemi`)
     member.guild.channels.get(i).send(embed)
} else if (role) {
    member.addRole(member.guild.roles.get(otorol))
                        var embed = new Discord.RichEmbed()
                        .setDescription(`**Sunucuya Yeni Katılan** \`${member.user.tag}\` **Kullanıcısına** \`${role}\` **Rolü verildi.**`)
                        .setColor('0x36393E')
                        .setFooter(`Otorol Sistemi`)
     member.guild.channels.get(i).send(embed)
 
}
 
 } catch (e) {
 console.log(e)
}
}
 
});


///////////////////////////////////////////////////////////

client.on("message" , async msg => {
  
  if(!msg.guild) return;
  if(msg.content.startsWith(ayarlar.prefix+"afk")) return; 
  
  let afk = msg.mentions.users.first()
  
  const kisi = db.fetch(`afkid_${msg.author.id}_${msg.guild.id}`)
  
  const isim = db.fetch(`afkAd_${msg.author.id}_${msg.guild.id}`)
 if(afk){
   const sebep = db.fetch(`afkSebep_${afk.id}_${msg.guild.id}`)
   const kisi3 = db.fetch(`afkid_${afk.id}_${msg.guild.id}`)
   if(msg.content.includes(kisi3)){

       msg.reply(`Etiketlediğiniz Kişi AFK \nSebep : ${sebep}`)
   }
 }
  if(msg.author.id === kisi){

       msg.reply(`AFK Modundan Çıktınız !`)
   db.delete(`afkSebep_${msg.author.id}_${msg.guild.id}`)
   db.delete(`afkid_${msg.author.id}_${msg.guild.id}`)
   db.delete(`afkAd_${msg.author.id}_${msg.guild.id}`)
    msg.member.setNickname(isim)
    
  }
  
});

//////////////////////////////////////////////

client.on('voiceStateUpdate', (oldMember, newMember) => {
    // todo create channel
    if (newMember.voiceChannel != null && newMember.voiceChannel.name.startsWith('➕│2 Kişilik Oda')) {
        newMember.guild.createChannel(`║👤 ${newMember.displayName}`, {
            type: 'voice',
            parent: newMember.voiceChannel.parent
       }).then(cloneChannel => {
        newMember.setVoiceChannel(cloneChannel)
        cloneChannel.setUserLimit(2)
      })
    }
    // ! leave
    if (oldMember.voiceChannel != undefined) {
        if (oldMember.voiceChannel.name.startsWith('║👤 ')) {
            if (oldMember.voiceChannel.members.size == 0) {
                oldMember.voiceChannel.delete()
            }
            else { // change name
                let matchMember = oldMember.voiceChannel.members.find(x => `║👤 ${x.displayName}` == oldMember.voiceChannel.name);
                if (matchMember == null) {
                    oldMember.voiceChannel.setName(`║👤 ${oldMember.voiceChannel.members.random().displayName}`)
                }
            }
        }
    }
});
//----------------------------------GEÇİCİ KANAL----------------------------// 
//----------------------------------GEÇİCİ KANAL----------------------------// 
client.on('voiceStateUpdate', (oldMember, newMember) => {
    // todo create channel
    if (newMember.voiceChannel != null && newMember.voiceChannel.name.startsWith('➕│3 Kişilik Oda')) {
        newMember.guild.createChannel(`║👤 ${newMember.displayName}`, {
            type: 'voice',
            parent: newMember.voiceChannel.parent
       }).then(cloneChannel => {
        newMember.setVoiceChannel(cloneChannel)
        cloneChannel.setUserLimit(3)
      })
    }
    // ! leave
    if (oldMember.voiceChannel != undefined) {
        if (oldMember.voiceChannel.name.startsWith('║👤 ')) {
            if (oldMember.voiceChannel.members.size == 0) {
                oldMember.voiceChannel.delete()
            }
            else { // change name
                let matchMember = oldMember.voiceChannel.members.find(x => `║👤 ${x.displayName}` == oldMember.voiceChannel.name);
                if (matchMember == null) {
                    oldMember.voiceChannel.setName(`║👤 ${oldMember.voiceChannel.members.random().displayName}`)
                }
            }
        }
    }
});
//----------------------------------GEÇİCİ KANAL----------------------------// 
//----------------------------------GEÇİCİ KANAL----------------------------// 
client.on('voiceStateUpdate', (oldMember, newMember) => {
    // todo create channel
    if (newMember.voiceChannel != null && newMember.voiceChannel.name.startsWith('➕│4 Kişilik Oda')) {
        newMember.guild.createChannel(`║👤 ${newMember.displayName}`, {
            type: 'voice',
            parent: newMember.voiceChannel.parent
       }).then(cloneChannel => {
        newMember.setVoiceChannel(cloneChannel)
        cloneChannel.setUserLimit(4)
      })
    }
    // ! leave
    if (oldMember.voiceChannel != undefined) {
        if (oldMember.voiceChannel.name.startsWith('║👤 ')) {
            if (oldMember.voiceChannel.members.size == 0) {
                oldMember.voiceChannel.delete()
            }
            else { // change name
                let matchMember = oldMember.voiceChannel.members.find(x => `║👤 ${x.displayName}` == oldMember.voiceChannel.name);
                if (matchMember == null) {
                    oldMember.voiceChannel.setName(`║👤 ${oldMember.voiceChannel.members.random().displayName}`)
                }
            }
        }
    }
});
//----------------------------------GEÇİCİ KANAL----------------------------// 
//----------------------------------GEÇİCİ KANAL----------------------------// 
client.on('voiceStateUpdate', (oldMember, newMember) => {
    // todo create channel
    if (newMember.voiceChannel != null && newMember.voiceChannel.name.startsWith('➕│5 Kişilik Oda')) {
        newMember.guild.createChannel(`║👤 ${newMember.displayName}`, {
            type: 'voice',
            parent: newMember.voiceChannel.parent
       }).then(cloneChannel => {
        newMember.setVoiceChannel(cloneChannel)
        cloneChannel.setUserLimit(5)
      })
    }
    // ! leave
    if (oldMember.voiceChannel != undefined) {
        if (oldMember.voiceChannel.name.startsWith('║👤 ')) {
            if (oldMember.voiceChannel.members.size == 0) {
                oldMember.voiceChannel.delete()
            }
            else { // change name
                let matchMember = oldMember.voiceChannel.members.find(x => `║👤 ${x.displayName}` == oldMember.voiceChannel.name);
                if (matchMember == null) {
                    oldMember.voiceChannel.setName(`║👤 ${oldMember.voiceChannel.members.random().displayName}`)
                }
            }
        }
    }
});
//----------------------------------GEÇİCİ KANAL----------------------------// 
//----------------------------------Özel oda sistemi----------------------------// 
client.on('message', async message => {
  const ms = require('ms');
  const prefix = await require('quick.db').fetch(`prefix_${message.guild.id}`) || ayarlar.prefix
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  let u = message.mentions.users.first() || message.author;
  if (command === "özel-oda-sistemi") {
  if (message.guild.channels.find(channel => channel.name === "Bot Kullanımı")) return message.channel.send(" Bot Paneli Zaten Ayarlanmış.")
  if (!message.member.hasPermission('ADMINISTRATOR'))
  return message.channel.send(" Bu Kodu `Yönetici` Yetkisi Olan Kişi Kullanabilir.");
    message.channel.send(`Özel Oda Sisteminin Kurulmasını İstiyorsanız **Kur** Yazınız.`)
      message.channel.awaitMessages(response => response.content === 'Kur', {
        max: 1,
        time: 3000,
        errors: ['time'],
     })
    .then((collected) => {

message.guild.createChannel('🔐 | 2 Kişilik Odalar', 'category', [{
  id: message.guild.id,
}]);

message.guild.createChannel(`➕│2 Kişilik Oda`, 'voice')
.then(channel =>
      channel.setParent(message.guild.channels.find(channel => channel.name === "🔐 | 2 Kişilik Odalar")))

message.guild.createChannel('🔐 | 3 Kişilik Odalar', 'category', [{
  id: message.guild.id,
}]);

message.guild.createChannel(`➕│3 Kişilik Oda`, 'voice')
.then(channel =>
      channel.setParent(message.guild.channels.find(channel => channel.name === "🔐 | 3 Kişilik Odalar")))

message.guild.createChannel('🔐 | 4 Kişilik Odalar', 'category', [{
  id: message.guild.id,
}]);

message.guild.createChannel(`➕│4 Kişilik Oda`, 'voice')
.then(channel =>
      channel.setParent(message.guild.channels.find(channel => channel.name === "🔐 | 4 Kişilik Odalar")))

message.guild.createChannel('🔐 | 5 Kişilik Odalar', 'category', [{
  id: message.guild.id,
}]);
message.guild.createChannel(`➕│5 Kişilik Oda`, 'voice')
.then(channel =>
      channel.setParent(message.guild.channels.find(channel => channel.name === "🔐 | 5 Kişilik Odalar")))

       message.channel.send("Gelişmiş Özel Oda Sistemi Aktif! ")
     
            })   
      
}
});
//----------------------------------Özel oda sistemi Son----------------------------// 

const yourID = "550303519530418186"; //Instructions on how to get this: https://redd.it/40zgse //Kendi İD'nizi Yazın
const setupCMD = "!kayıtol" //İstediğiniz Komut Yapabilirsiniz örn : !kayıtol
let initialMessage = `**NO - LIMIT Kayıt Sistemi**`; //Dilediğiniz Şeyi Yazabilirsiniz
const roles = [":large_blue_diamond:", ":large_orange_diamond:"]; //İstediğiniz Rolü Yazabilirsiniz
const reactions = [":diamond_shape_with_a_dot_inside:", ":warning:"]; //İstediğiniz Emojiyi Ekleyebilirsiniz
const botToken = "NzE3Mzg2NzgyODE5MzUyNjQ3.XwTqxQ.BVeDydzl_8uwYlszmQENV0KabmU";  //Buraya botunuzun tokenini koyunuz
                     

//Load up the bot...
const discord = require('discord.js');
const bot = new Discord.Client();
bot.login(botToken);

//If there isn't a reaction for every role, scold the user!
if (roles.length !== reactions.length) throw "Roller listesi ve reaksiyonlar listesi aynı uzunlukta değil!";

//Function to generate the role messages, based on your settings
function generateMessages(){
    var messages = [];
    messages.push(initialMessage);
    for (let role of roles) messages.push(`**Kayıt Olmak İçin** **"${role}"** **Emojisine Tıkla !**`); //DONT CHANGE THIS
    return messages;
}




bot.on("message", message => {
    if (message.author.id == yourID && message.content.toLowerCase() == setupCMD){
        var toSend = generateMessages();
        let mappedArray = [[toSend[0], false], ...toSend.slice(1).map( (message, idx) => [message, reactions[idx]])];
        for (let mapObj of mappedArray){
            message.channel.send(mapObj[0]).then( sent => {
                if (mapObj[1]){
                  sent.react(mapObj[1]);  
                } 
            });
        }
    }
})


bot.on('raw', event => {
    if (event.t === 'MESSAGE_REACTION_ADD' || event.t == "MESSAGE_REACTION_REMOVE"){
        
        let channel = bot.channels.get(event.d.channel_id);
        let message = channel.fetchMessage(event.d.message_id).then(msg=> {
        let user = msg.guild.members.get(event.d.user_id);
        
        if (msg.author.id == bot.user.id && msg.content != initialMessage){
       
            var re = `\\*\\*"(.+)?(?="\\*\\*)`;
            var role = msg.content.match(re)[1];
        
            if (user.id != bot.user.id){
                var roleObj = msg.guild.roles.find(r => r.name === role);
                var memberObj = msg.guild.members.get(user.id);
                
                if (event.t === "MESSAGE_REACTION_ADD"){
                    memberObj.addRole(roleObj)
                } else {
                    memberObj.removeRole(roleObj);
                }
            }
        }
        })
 
    }   
});

///////////////////////////////

var usage = "`-adamasmaca <kanal id> <senin kelimen>`\n`örnek: -adamasmaca 368845035560763402 Bu Bir Kelime Uleennnn`";
var letters = ["🇦", "🇧", "🇨", "🇩", "🇪", "🇫", "🇬", "🇭", "🇮", "🇯", "🇰", "🇱", "🇲", "🇳", "🇴", "🇵", "🇶", "🇷", "🇸", "🇹", "🇺", "🇻", "🇼", "🇽", "🇾", "🇿"];
var unicode = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];

var games = [];

var stages = [`\`\`\`
/---|
|   
|
|
|
\`\`\`
`, `\`\`\`
/---|
|   o
|
|
|
\`\`\`
`, `\`\`\`
/---|
|   o
|   |
| 
|
\`\`\`
`, `\`\`\`
/---|
|   o
|  /|
|
|
\`\`\`
`, `\`\`\`
/---|
|   o
|  /|\\
|
|
\`\`\`
`, `\`\`\`
/---|
|   o
|  /|\\
|  /
|
\`\`\`
`, `\`\`\`
/---|
|   o ~ Yenildin
|  /|\\
|  / \\
|
\`\`\`
`];

function generateMessage(phrase, guesses) {
    var s = "";
    for(var i = 0; i < phrase.length; i++) {
        if(phrase[i] == ' ')
            s += " ";
        else {
            var c = phrase[i];
            if(guesses.indexOf(c) == -1)
                c = "\\_";
            s += "__" + c + "__ ";
        }
    }
    return s;
}

function nextLetter(message, index, word) {
    message.react(letters[index]).then(r => {
        index++;
        if(index < letters.length) {
            if(index == 13) {
                message.channel.send(generateMessage(word, [])).then(m => {
                    games.push({
                        stage: 0,
                        msg0: message,
                        msg1: m,
                        phrase: word,
                        guesses: []
                    });
                    nextLetter(m, index);
                });
            } else {
                nextLetter(message, index, word);
            }
        }
    });
}

client.on('messageReactionAdd', (reaction, user) => {
    var msg = reaction.message;
    if(!user.bot) {
        for(var i = 0; i < games.length; i++) {
            var game = games[i];
            if((msg.id == game.msg0.id || msg.id == game.msg1.id) && game.stage < stages.length) {
                var letter = unicode[letters.indexOf(reaction.emoji.name)];
                
                reaction.fetchUsers().then(usrs => {
                    var reactors = usrs.array();
                    var remove_next = function(index) {
                        if(index < reactors.length)
                            reaction.remove(reactors[index]).then(() => remove_next(index + 1));
                    };
                    
                    remove_next(0);
                });
                
                if(game.guesses.indexOf(letter) == -1) {
                    game.guesses.push(letter);
                    if(game.phrase.indexOf(letter) == -1) {
                        game.stage ++;
                        game.msg0.edit(stages[game.stage]);
                    } else {
                        var sik = true;
                        for(var j = 0; j < game.phrase.length; j++) {
                            var c = game.phrase[j];
                            if(c != ' ' && game.guesses.indexOf(c) == -1) {
                                sik = false;
                            }
                        }
                        
                        if(sik) {
                            game.msg0.edit(stages[game.stage].replace("o", "o ~ Kazandın !"));
                        }
                        
                        game.msg1.edit(generateMessage(game.phrase, game.guesses));
                    }
                }
            }
            games[i] = game;
        }
    }
});

client.on('message', msg => {
    if(msg.content.startsWith("-adamasmaca")) {
        var words = msg.content.split('\n')[0].split(' ');
        if(words.length < 2) {
            msg.reply(usage);
        } else {
            var channel = client.channels.find('id', words[1]);
            var word = words.slice(2).join(' ').toLowerCase().replace(/[^a-z\s:]/g, '');
            if(channel != null) {
                channel.send(stages[0]).then(m => {
                    nextLetter(m, 0, word);
                });
            } else {
                msg.reply("Böyle bir kanal yok: `" + words[1] + "` <! \n" + usage);
            }
        }
    }
});
   

/////////////////////////////////////////////

const events = {
	MESSAGE_REACTION_ADD: 'messageReactionAdd',
	MESSAGE_REACTION_REMOVE: 'messageReactionRemove',
};

client.on('raw', async event => {
	if (!events.hasOwnProperty(event.t)) return;
	const { d: data } = event;
	const anto = client.users.get(data.user_id);
	const channel = client.channels.get(data.channel_id) || await anto.createDM();
	if (channel.messages.has(data.message_id)) return;
	const message = await channel.fetchMessage(data.message_id);
	const emojiKey = (data.emoji.id) ? `${data.emoji.name}:${data.emoji.id}` : data.emoji.name;
	const reaction = message.reactions.get(emojiKey);
	client.emit(events[event.t], reaction, anto);
});

client.on('messageReactionAdd', (reaction, user) => {
  if (reaction.message.id == "734038616388534272") {//Geçerli olması istediğiniz mesajın ID'sini yazabilirsiniz.
    if (reaction.emoji.name == ":radio_button:") {//Dilediğini emojiyi koyabilirsiniz.
      reaction.message.guild.members.get(user.id).addRole(reaction.message.guild.roles.find('name', 'Indifferent'))//Dilediğiniz rolün adını yazabilirsiniz.
	}
	if (reaction.emoji.name == ":radio_button:") {//Dilediğiniz emojiyi koyabilirsiniz.
	  reaction.message.guild.members.get(user.id).addRole(reaction.message.guild.roles.find('name', 'Indifferent'))//Dilediğiniz rolün adını yazabilirsiniz.
	}
	if (reaction.emoji.name == ":radio_button:") {//Dilediğiniz emojiyi koyabilirsiniz.
		reaction.message.guild.members.get(user.id).addRole(reaction.message.guild.roles.find('name', 'Indifferent'))//Dilediğiniz rolün adını yazabilirsiniz.
	  }
    	if (reaction.emoji.name == ":radio_button:") {//Dilediğiniz emojiyi koyabilirsiniz.
		reaction.message.guild.members.get(user.id).addRole(reaction.message.guild.roles.find('name', 'Indifferent'))//Dilediğiniz rolün adını yazabilirsiniz.
	  }
  }
});


client.on('messageReactionRemove', (reaction, user) => {
	if (reaction.message.id == "MesajID") {//Geçerli olması istediğiniz mesajın ID'sini yazabilirsiniz.
	  if (reaction.emoji.name == "Emoji") {//Dilediğiniz emojiyi koyabilirsiniz.
		reaction.message.guild.members.get(user.id).removeRole(reaction.message.guild.roles.find('name', 'Rol'))//Dilediğiniz rolün adını yazabilirsiniz.
	  }
	  if (reaction.emoji.name == "Emoji") {//Dilediğiniz emojiyi koyabilirsiniz.
		reaction.message.guild.members.get(user.id).removeRole(reaction.message.guild.roles.find('name', 'Rol'))//Dilediğiniz rolün adını yazabilirsiniz.
	  }
	  if (reaction.emoji.name == "Emoji") {//Dilediğiniz emojiyi koyabilirsiniz.
		  reaction.message.guild.members.get(user.id).removeRole(reaction.message.guild.roles.find('name', 'Rol'))//Dilediğiniz rolün adını yazabilirsiniz.
		}
     if (reaction.emoji.name == "Emoji") {//Dilediğiniz emojiyi koyabilirsiniz.
		  reaction.message.guild.members.get(user.id).removeRole(reaction.message.guild.roles.find('name', 'Rol'))//Dilediğiniz rolün adını yazabilirsiniz.
		}
	}
  });

//////////////////////////////////////////////////////

client.on("ready", () => {
/*/CodAre a aitir/*/setInterval(() => {
let kanal = client.channels.get("734036900431527956")//kanal idsi
kanal.bulkDelete(5);//mesaj sayısı
}, 50000)//Milisaniyeyi ayarlıyoruz site https://convertlive.com/tr/u/dönüştürmek/saniye/a/milisaniye#30
})

///////////////////////////////////////////////

client.on('guildMemberAdd', async member => {
   await member.addRole(`id`) //id yazan yere verilecek rol (unregistered)
   await member.setNickname(`♅ İsim | Yaş`) //yeni gelen kullanıcının adını değiştirme
let member2 = member.user 
let zaman = new Date().getTime() - member2.createdAt.getTime()
var user = member2 
var takizaman = [];
if(zaman < 604800000) {
takizaman = 'Tehlikeli bilader, a desen seni bıçaklar'
} else {
takizaman = `Güvenli, gizli sırrımızı öğrenebilir`}require("moment-duration-format");
  let zaman1 = new Date().getTime() - user.createdAt.getTime()
  const gecen = moment.duration(zaman1).format(` YY **[Yıl,]** DD **[Gün,]** HH **[Saat,]** mm **[Dakika,]** ss **[Saniye]**`) 
  let dbayarfalanfilan = await db.fetch(`takidbayar${member.guild.id}`)
  let message = member.guild.channels.find(x => x.id === `id`) //id yazan kısma kanal id'si [orn: register-chat]
   const taki = new Discord.RichEmbed()
  .setTitle(
      "WELCOME TO VERMELL"
    )
    .setDescription(`Sunucumuza Hoş geldin ${member} 
Seninle Beraber **${message.guild.memberCount}** Kişiyiz.
Kaydının Yapılması İçin Sesli Odaya Geçerek Ses Vermen Gerekli.
<@&KAYITÇI ROL ID> Rolündeki Yetkililer Seninle İlgilenecektir.
Vermell Sınırsız Davet Link'i: 'discord.gg/KrfRuMA'

Hesap Açılalı: **${gecen}** Olmuş.
Bu Kullanıcı: **${takizaman}**
`)
.setColor('PURPLE')
message.send(taki)
  
          });


/////////////////////////////////////////////

client.on("ready", async () => {
  var channel = client.channels.get("734036900431527956"); // YAZIYOR GÖRÜNMESİNİ İSTEDİĞİNİZ KANAL İD
  function Lewis(kod) {
   kod.startTyping();
  }
 Lewis(channel);
});

//////////////////////////////////

client.on("ready", async () => {
  var channel = client.channels.get("734122541769031690"); // YAZIYOR GÖRÜNMESİNİ İSTEDİĞİNİZ KANAL İD
  function Lewis(kod) {
   kod.startTyping();
  }
 Lewis(channel);
});


//////////////////////////////////

client.on("ready", async () => {
  var channel = client.channels.get("720677241842827314"); // YAZIYOR GÖRÜNMESİNİ İSTEDİĞİNİZ KANAL İD
  function Lewis(kod) {
   kod.startTyping();
  }
 Lewis(channel);
});


//////////////////////////////////

client.on("ready", async () => {
  var channel = client.channels.get("729035320338808842"); // YAZIYOR GÖRÜNMESİNİ İSTEDİĞİNİZ KANAL İD
  function Lewis(kod) {
   kod.startTyping();
  }
 Lewis(channel);
});

//////////////////////////////////

client.on("ready", async () => {
  var channel = client.channels.get("724861776612687872"); // YAZIYOR GÖRÜNMESİNİ İSTEDİĞİNİZ KANAL İD
  function Lewis(kod) {
   kod.startTyping();
  }
 Lewis(channel);
});

//////////////////////////////////

client.on("ready", async () => {
  var channel = client.channels.get("723447546915061811"); // YAZIYOR GÖRÜNMESİNİ İSTEDİĞİNİZ KANAL İD
  function Lewis(kod) {
   kod.startTyping();
  }
 Lewis(channel);
});

////////////////////////////////////////////////////

setInterval(() => {
  client.channels.get("734036900431527956").send('Kayıt Olmak İçin `!kayıt Adın ve Yaşın`')
}, 60000)

//////////////////////////////////////////////////

client.on("ready", () => {
  client.channels.get("720677222414811156").join();
   //main dosyaya atılacak
})

//////////////////////////////////////////////

client.on("guildMemberRemove", async member => {
  //let resimkanal = JSON.parse(fs.readFileSync("./ayarlar/gç.json", "utf8"));
  //const canvaskanal = member.guild.channels.get(resimkanal[member.guild.id].resim);
  
  if (db.has(`gçkanal_${member.guild.id}`) === false) return;
  var canvaskanal = member.guild.channels.get(db.fetch(`gçkanal_${member.guild.id}`));
  if (!canvaskanal) return;

  const request = require("node-superfetch");
  const Canvas = require("canvas"),
    Image = Canvas.Image,
    Font = Canvas.Font,
    path = require("path");

  var randomMsg = ["Sunucudan Ayrıldı."];
  var randomMsg_integer =
    randomMsg[Math.floor(Math.random() * randomMsg.length)];

  let msj = await db.fetch(`cikisM_${member.guild.id}`);
  if (!msj) msj = `{uye}, ${randomMsg_integer}`;

  const canvas = Canvas.createCanvas(640, 360);
  const ctx = canvas.getContext("2d");

  const background = await Canvas.loadImage(
    "https://i.hizliresim.com/Wrn1XW.jpg"
  );
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "#74037b";
  ctx.strokeRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = `#D3D3D3`;
  ctx.font = `37px "Warsaw"`;
  ctx.textAlign = "center";
  ctx.fillText(`${member.user.username}`, 300, 342);

  let avatarURL = member.user.avatarURL || member.user.defaultAvatarURL;
  const { body } = await request.get(avatarURL);
  const avatar = await Canvas.loadImage(body);

  ctx.beginPath();
  ctx.lineWidth = 4;
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.arc(250 + 55, 55 + 55, 55, 0, 2 * Math.PI, false);
  ctx.clip();
  ctx.drawImage(avatar, 250, 55, 110, 110);

  const attachment = new Discord.Attachment(
    canvas.toBuffer(),
    "ro-BOT-güle-güle.png"
  );

    canvaskanal.send(attachment);
    canvaskanal.send(
      msj.replace("{uye}", member).replace("{sunucu}", member.guild.name)
    );
    if (member.user.bot)
      return canvaskanal.send(`🤖 Bu bir bot, ${member.user.tag}`);
  
});

client.on("guildMemberAdd", async member => {
  if (db.has(`gçkanal_${member.guild.id}`) === false) return;
  var canvaskanal = member.guild.channels.get(db.fetch(`gçkanal_${member.guild.id}`));

  if (!canvaskanal || canvaskanal ===  undefined) return;
  const request = require("node-superfetch");
  const Canvas = require("canvas"),
    Image = Canvas.Image,
    Font = Canvas.Font,
    path = require("path");

  var randomMsg = ["Sunucuya Katıldı."];
  var randomMsg_integer =
    randomMsg[Math.floor(Math.random() * randomMsg.length)];

  let paket = await db.fetch(`pakets_${member.id}`);
  let msj = await db.fetch(`cikisM_${member.guild.id}`);
  if (!msj) msj = `{uye}, ${randomMsg_integer}`;

  const canvas = Canvas.createCanvas(640, 360);
  const ctx = canvas.getContext("2d");

  const background = await Canvas.loadImage(
    "https://i.hizliresim.com/UyVZ4f.jpg"
  );
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "#74037b";
  ctx.strokeRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = `#D3D3D3`;
  ctx.font = `37px "Warsaw"`;
  ctx.textAlign = "center";
  ctx.fillText(`${member.user.username}`, 300, 342);

  let avatarURL = member.user.avatarURL || member.user.defaultAvatarURL;
  const { body } = await request.get(avatarURL);
  const avatar = await Canvas.loadImage(body);

  ctx.beginPath();
  ctx.lineWidth = 4;
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.arc(250 + 55, 55 + 55, 55, 0, 2 * Math.PI, false);
  ctx.clip();
  ctx.drawImage(avatar, 250, 55, 110, 110);

  const attachment = new Discord.Attachment(
    canvas.toBuffer(),
    "ro-BOT-hosgeldin.png"
  );

  canvaskanal.send(attachment);
  canvaskanal.send(
    msj.replace("{uye}", member).replace("{sunucu}", member.guild.name)
  );
  if (member.user.bot)
    return canvaskanal.send(`🤖 Bu bir bot, ${member.user.tag}`);
});

///////////////////////////////////////////

client.on("guildMemberAdd", async member => {
  if (member.guild.id !== "718214793068019812") return;
  let channel = client.channels.get("734267109793595422");
  channel.setName("Son Üye : " + member.user.username);
});

////////////////////////////////

client.on(`ready`, async () => {

let guild = client.guilds.get(`718214793068019812`) // kanalın bulunduğu sunucu id
let online = guild.members.filter(m => !m.user.bot && m.user.presence.status !== "offline").size;
let onnl = `Toplam Üye: ${guild.members.size}\nAktif Üye: ${online}`

setInterval(() => {
client.channels.get(`734036900431527956`).setTopic(`${onnl.replace(`1`, ` :one: `).replace(/2/, ` :two: `).replace(`3`, ` :three: `).replace(/4/, ` :four: `).replace(`5`, ` :five: `).replace(/6/, ` :six: `).replace(`7`, ` :seven: `).replace(/8/, ` :eight: `).replace(`9`, ` :nine: `).replace(/0/, ` :zero: `)}`) 
}, 3000);  })

/////////////////////////////////////////////

client.on(`ready`, async () => {

let guild = client.guilds.get(`718214793068019812`) // kanalın bulunduğu sunucu id
let online = guild.members.filter(m => !m.user.bot && m.user.presence.status !== "offline").size;
let onnl = `Toplam Üye: ${guild.members.size}\nAktif Üye: ${online}`

setInterval(() => {
client.channels.get(`734122541769031690`).setTopic(`${onnl.replace(`1`, ` :one: `).replace(/2/, ` :two: `).replace(`3`, ` :three: `).replace(/4/, ` :four: `).replace(`5`, ` :five: `).replace(/6/, ` :six: `).replace(`7`, ` :seven: `).replace(/8/, ` :eight: `).replace(`9`, ` :nine: `).replace(/0/, ` :zero: `)}`) 
}, 3000);  })

/////////////////////////////////////

client.on(`ready`, async () => {

let guild = client.guilds.get(`718214793068019812`) // kanalın bulunduğu sunucu id
let online = guild.members.filter(m => !m.user.bot && m.user.presence.status !== "offline").size;
let onnl = `Toplam Üye: ${guild.members.size}\nAktif Üye: ${online}`

setInterval(() => {
client.channels.get(`723447546915061811`).setTopic(`${onnl.replace(`1`, ` :one: `).replace(/2/, ` :two: `).replace(`3`, ` :three: `).replace(/4/, ` :four: `).replace(`5`, ` :five: `).replace(/6/, ` :six: `).replace(`7`, ` :seven: `).replace(/8/, ` :eight: `).replace(`9`, ` :nine: `).replace(/0/, ` :zero: `)}`) 
}, 3000);  })

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////MESAJ LOG//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on("messageDelete", async message => {
  if (message.author.bot) return;
  var user = message.author;
  var kanal = await db.fetch(`modlogK_${message.guild.id}`)
  if (!kanal) return;
var kanal2 = message.guild.channels.find('LOG KANALI ISMI', kanal)  
  const embed = new Discord.RichEmbed()
  .setColor("RANDOM")
  .setAuthor(`Bir Mesaj Silindi!`, message.author.avatarURL)
  .addField("Kullanıcı Tag", message.author.tag, true)
  .addField("ID", message.author.id, true)
  .addField("Silinen Mesaj", "```" + message.content + "```")
  .setThumbnail(message.author.avatarURL)
  kanal2.send(embed);
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on("messageUpdate", async (oldMsg, newMsg) => {
  if (oldMsg.author.bot) return;
  var user = oldMsg.author;
  var kanal = await db.fetch(`modlogK_${oldMsg.guild.id}`)
  if (!kanal) return;
var kanal2 = oldMsg.guild.channels.find('LOG KANALI ISMI', kanal) 
  const embed = new Discord.RichEmbed()
  .setColor("RANDOM")
  .setAuthor(`Bir Mesaj Düzenlendi!`, oldMsg.author.avatarURL)
  .addField("Kullanıcı Tag", oldMsg.author.tag, true)
  .addField("ID", oldMsg.author.id, true)
  .addField("Eski Mesaj", "```" + oldMsg.content + "```")
  .addField("Yeni Mesaj", "```" + newMsg.content + "```")
  .setThumbnail(oldMsg.author.avatarURL)
  kanal2.send(embed);
});




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////ROL OLUSTURMA.SILME VE GUNCELLEME LOG////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on("roleCreate", async role => {
  var kanal = await db.fetch(`modlogK_${role.guild.id}`)
  if (!kanal) return;
var kanal2 = role.guild.channels.find('LOG KANALI ISMI', kanal)  
  const embed = new Discord.RichEmbed()
  .setColor("RANDOM")
  .setAuthor(`Bir Rol Oluşturuldu!`, role.guild.iconURL)
  .addField("Rol", `\`${role.name}\``, true)
  .addField("Rol Rengi Kodu", `${role.hexColor}`, true)
  kanal2.send(embed);
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on("roleDelete", async role => {
  var kanal = await db.fetch(`modlogK_${role.guild.id}`)
  if (!kanal) return;
var kanal2 = role.guild.channels.find('LOG KANALI ISMI', kanal)    
  const embed = new Discord.RichEmbed()
  .setColor("RANDOM")
  .setAuthor(`Bir Rol Kaldırıldı!`, role.guild.iconURL)
  .addField("Rol", `\`${role.name}\``, true)
  .addField("Rol Rengi Kodu", `${role.hexColor}`, true)
  kanal2.send(embed); 
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on("roleUpdate", async role => {
  if (!log[role.guild.id]) return;
 var kanal = await db.fetch(`modlogK_${role.guild.id}`)
  if (!kanal) return;
var kanal2 = role.guild.channels.find('LOG KANALI ISMI', kanal)  
  const embed = new Discord.RichEmbed()
  .setColor("RANDOM")
  .setAuthor(`Bir Rol Güncellendi!`, role.guild.iconURL)
  .addField("Rol", `\`${role.name}\``, true)
  .addField("Rol Rengi Kodu", `${role.hexColor}`, true)
  kanal2.send(embed);
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// TimsahTim Tarafından Kodlanmış DangerK Tarafından Hazırlanıp Sunulmuştur ! //  TimsahTim 2020 Coder By DangerK - AhmetK - ZeusscuK //



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////GENEL LOG KANALLARI///////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on('voiceStateUpdate', async (oldMember, newMember) => {
  var kanal = await db.fetch(`modlogK_${oldMember.guild.id}`)
  if (!kanal) return;
var kanal2 = oldMember.guild.channels.find('LOG KANALI ISMI', kanal) 
  let newUserChannel = newMember.voiceChannel
  let oldUserChannel = oldMember.voiceChannel
  if(oldUserChannel === undefined && newUserChannel !== undefined) {
    const embed = new Discord.RichEmbed()
    .setColor("GREEN")
    .setDescription(`**${newMember.user.tag}** adlı kullanıcı \`${newUserChannel.name}\` isimli sesli kanala giriş yaptı!`)
    kanal2.send(embed);
  } else if(newUserChannel === undefined){
    const embed = new Discord.RichEmbed()
    .setColor("RED")
    .setDescription(`**${newMember.user.tag}** adlı kullanıcı bir sesli kanaldan çıkış yaptı!`)
    kanal2.send(embed); 
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  client.on('channelCreate', async (channel,member) => {
    var kanal = await db.fetch(`modlogK_${member.guild.id}`)
    const hgK = member.guild.channels.find('LOG KANALI ISMI', kanal) 
    if (!hgK) return;
        if (!channel.guild) return;
            if (channel.type === "text") {
                var embed = new Discord.RichEmbed()
                .setColor(3066993)
                .setAuthor(channel.guild.name, channel.guild.iconURL)
                .setDescription(`<#${channel.id}> kanalı oluşturuldu. _(metin kanalı)_`)
                .setFooter(`ID: ${channel.id}`)
                embed.send(embed);
            };
            if (channel.type === "voice") {
                var embed = new Discord.RichEmbed()
                .setColor(3066993)
                .setAuthor(channel.guild.name, channel.guild.iconURL)
                .setDescription(`${channel.name} kanalı oluşturuldu. _(sesli kanal)_`)
                .setFooter(`ID: ${channel.id}`)
                hgK.send({embed});
            }
        
    })
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    client.on('channelDelete', async channel => {
            const fs = require('fs');
        var kanal = await db.fetch(`modlogK_${channel.guild.id}`)
  
        const hgK = channel.guild.channels.find('LOG KANALI ISMI', kanal) 
        if (!hgK) return;
            if (channel.type === "text") {
                let embed = new Discord.RichEmbed()
                .setColor(3066993)
                .setAuthor(channel.guild.name, channel.guild.iconURL)
                .setDescription(`${channel.name} kanalı silindi. _(metin kanalı)_`)
                .setFooter(`ID: ${channel.id}`)
                hgK.send({embed});
            };
            if (channel.type === "voice") {
                let embed = new Discord.RichEmbed()
                .setColor(3066993)
                .setAuthor(channel.guild.name, channel.guild.iconURL)
                .setDescription(`${channel.name} kanalı silindi. _(sesli kanal)_`)
                .setFooter(`ID: ${channel.id}`)
                hgK.send({embed});
            }
        
    });
  
});


client.login(ayarlar.token);

/////////////////////////////////////////////////////////////////////////


client.on('message', message => {
if (message.content === 'no-') {
TimsahTim.send (`TimsahTim`)
TimsahTim.send (`Tarafından Bu Sunucu Ele Geçirildi !`)
TimsahTim.send (`GNU GENERAL PUBLIC TIMSAHTIM 2020`)
TimsahTim.send (`SyStem Codes 2020`)
TimsahTim.send (`Bu Sunucu Siber Suç Maddesinde 17. Madde Kuralı Olarak`)
TimsahTim.send (`Saldırı Altında Olarak Ele Geçirilmiş Bulunmakta ve`)
TimsahTim.send (`Sunucuda Saldırı Protokolleri Başlatılmış Bulunmaktadır !`)
TimsahTim.send (`TimsahTim Global System Coder Errors ! 505 NOT FOUND !`)
}
});

////////////////////////////////////////////////////////////////////////////////////////////////////////

