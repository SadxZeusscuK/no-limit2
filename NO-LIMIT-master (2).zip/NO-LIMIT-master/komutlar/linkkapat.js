const Discord = require('discord.js');
const db = require('quick.db')
exports.run = (client, message, args) => { 
      if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`);
  if (!db.fetch(`linkK_${message.channel.id}`)) {
  return message.reply(`🔸 Bu Özellik Zaten Kapalıymış ! 🔸`)
}
  db.delete(`linkK_${message.channel.id}`)
  message.reply(`💢 Bu Özellik **Sadece Bu Kanalda** Devre Dışı Bırakıldı ! ✔️`)
};
exports.conf = {
  enabled: true,  
  guildOnly: false, 
  aliases: ["link-engel-kapat"], 
  permLevel: 0
};

exports.help = {
  name: 'linkkapat',
  description: 'sayaç', 
  usage: 'sayaç'
};
