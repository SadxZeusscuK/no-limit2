const Discord = require('discord.js');
const moment = require('moment');


exports.run = (client, message, args) => {
  if(!message.member.hasPermission('ADMINISTRATOR')) return message.reply('💢 Bu Komutu Kullanabilmek İçin `Yönetici` İznine Sahip Olmalısın ! 📛')

 let kanal = args.slice(0).join(' ');
    let guild = message.guild;
    if (!message.member.hasPermission("MANAGE_CHANNELS"))

message.channel.sendMessage(' **🔄 Botun Yeniden Başlatılmasını Onaylıyor Musununuz ?**')
.then(() => {
  message.channel.awaitMessages(response => response.content === "evet", {
    max: 1,
    time: 30000,
    errors: ['time'],
  })
  .then((collected) => {
      message.channel.sendMessage('  **🔄 Yeniden Başlatılıyorum !**   ').then(message => {
      console.log(`[${moment().format('YYYY-MM-DD HH:mm:ss')}] :space_invader: **Bot Yeniden Başlatılıyor** :space_invader:`)
      process.exit(1);
    }).catch(console.error)
    })
    .catch(() => {
      message.channel.sendMessage(' `Yeniden Başlama İşlemini İptal Ettim !` ');
    });
});
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['yenile','yb'],
  permLevel: 4
};

exports.help = {
  name: 'reboot',
  description: '[YAPIMCI]',
  usage: 'reboot'
};
