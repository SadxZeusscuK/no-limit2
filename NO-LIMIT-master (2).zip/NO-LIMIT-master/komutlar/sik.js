const Discord = require('discord.js')

exports.run = (client, message, args) => {
  let user = message.mentions.users.first();
  if(!user) return message.channel.send('Sikeceğin Kullanıcıyı Etiketlemen Gerekiyor !')
  if (user.id === message.author.id) return message.reply('Kendini Sikemessin Olum Sakin Ol ! 😂');

    
  if ( message.react('💞')) {
      var gif = [
      'https://cdn.discordapp.com/attachments/700646722564784180/733055307890032790/tumblr_48902058869827ab2e384e3c78d254b9_3094a0c0_500.gif', 'https://cdn.discordapp.com/attachments/700646722564784180/733055477100838962/hareketli-siki-resimleri-9.gif', 'https://cdn.discordapp.com/attachments/700646722564784180/733055592259780648/unnamed.gif', 'https://cdn.discordapp.com/attachments/700646722564784180/733055990252961872/kjb12hb312.gif', 'https://cdn.discordapp.com/attachments/700646722564784180/733056113364303902/98647123.gif', 'https://cdn.discordapp.com/attachments/700646722564784180/733056265852551300/123123.gif', 'https://cdn.discordapp.com/attachments/700646722564784180/733056394864885790/12341232.gif'];

      var gifler = gif[Math.floor(Math.random() * gif.length)];
  }
    
    if (message.react('💞')) {
    const op = new Discord.RichEmbed()
    .setDescription(`<@${message.author.id}>` + ` <@${user.id}>'ı Fena Haşamat Etti <3`)
    .setColor('RANDOM')
    .setImage(gifler)
    return message.channel.send(op)
    }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'sik',
  description: 'sik',
  usage: 'sik'
};
