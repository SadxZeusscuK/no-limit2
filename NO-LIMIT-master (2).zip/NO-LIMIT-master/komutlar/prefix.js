const db = require('quick.db');

exports.run = (client, message, args, func) => {
  
  if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`);
  
  let preffix = db.fetch(`prefix_${message.guild.id}`)
  
    if(args[0] === "sıfırla") {
    if(!preffix) {
      message.channel.send(`Ayarlanmayan Prefix'i Sıfırlayamazsın !`)
      return
    }
    
    db.delete(`prefix_${message.guild.id}`)
    message.channel.send(`Başarılı! () Mevcut prefix \`-\``)
            message.react('617413726768988160')
    return
  }
  
  if (!args[0])
    return message.channel.send(`Bir Prefix Girmelisin !`)
  db.set(`prefix_${message.guild.id}`, args[0])
    message.channel.send(`Prefix \`${args[0]}\` Olarak Başarıyla Ayarlandı ! ✅`)
        message.react('617413726768988160')
  
};

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ['prefix-ayarla'],
    kategori: 'ayarlar',
    permLevel: 3
};
  
  exports.help = {
    name: 'prefix-ayarla',
    description: 'Bota eklenmesini istediğiniz şeyi tavsiye etmenizi sağlar',
    usage: 'prefix-ayarla <prefix>'
};
