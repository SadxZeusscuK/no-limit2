const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
 
 const Embed = new Discord.RichEmbed()
 .setTimestamp()
 .setAuthor("NO - LIMIT", client.user.avatarURL)
.setColor("RANDOM")
.setTitle("İşletme Sahibi İle Fantezi Yataklar :D")
 .setURL("https://www.xvideos.com/video49368225/real_wife_stories_-_abigail_mac_keiran_lee_-_nailed_at_the_estate_sale_-_brazzers")
 .setTitle("Ev Satın Alımı HardCore Karı Araklama :D")
 .setURL("https://www.xvideos.com/video54513233/real_wife_stories_-_nina_milano_keiran_lee_-_a_fair_deal_-_brazzers")
  .setTitle("Masörler Artık Seks Hizmeti Vermeye Başlamış :D")
 .setURL("https://www.xvideos.com/video37426087/private_treatment_starring_natasha_nice_and_johnny_sins")
   .setTitle("Otel Tatilinde Araklama Seks")
 .setURL("https://www.xvideos.com/video23275491/familystrokes_-_family_vacation_turns_into_sibling_fucking")
   .setTitle("Kol Sakatken Bile Seks")
 .setURL("https://www.xvideos.com/video33689233/brother_fucked_to_his_sister_caught_jerking")
   .setTitle("Günlük Seks")
 .setURL("https://www.xvideos.com/video52549745/big_sister_and_brother_share_a_room_-_natasha_nice_-_family_therapy_-_preview")
   .setTitle("Koca Çalma Saatleri :D")
 .setURL("https://www.xvideos.com/video28941245/pornstars_like_it_big_-_theres_a_pornstar_in_my_house_scene_starring_nicole_aniston_and_jessy_jones")


 .setFooter("NO - LIMIT", client.user.avatarURL)
 message.channel.send(Embed)
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["porn","porno","sex","porn"],
  permLevel: 0
};

module.exports.help = {
  name: 'porn',
  description: 'Porno Menüsünü Gösterir.',
  usage: 'porn'
};
