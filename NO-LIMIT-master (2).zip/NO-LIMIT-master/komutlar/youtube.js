  
const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {



    let youtube = args.slice(0).join('+');

        let link = `https://www.youtube.com/results?search_query=` + youtube;
        if(!youtube)return message.reply(`🛑 Lütfen Bir Kanal Adı Ve Ya Video Başlığı Girin ! 💢`)
        if(!link)return message.reply("Console error")
        let embed = new Discord.RichEmbed()
 
         
     .setColor("BLUE")
         
          .setTimestamp()
        
          .addField('Aktivasyon:', '💠 Youtube da Aranıyor ! ')

          .addField("Aranan:", `${args.slice(0).join(' ')}`)

          .addField('Link:', `${link}`)
         
          .setFooter("Avatarın", message.author.avatarURL);
          
              
              message.author.send(`**💻 Aradığın Bağlantı Başarıyla Bulundu ! ✅** ${link} - - - Komutu Girdiğin Sunucu: ${ message.guild.name}`);

        
    
}



exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'youtube',
  description: 'Tüm Komutları Listeler .  İsterseniz Bir Komut Hakkında Yardım Eder..',
  usage: 'youtube'
};
