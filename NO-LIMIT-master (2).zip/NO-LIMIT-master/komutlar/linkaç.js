const Discord = require('discord.js');
const db = require('quick.db')
exports.run = (client, message, args) => { 
      if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`);
  if (db.fetch(`linkK_${message.channel.id}`)) {
  return message.reply(`🔹 Bu Özellik Zaten Açıkmış ! 🔹`)
}
  db.set(`linkK_${message.channel.id}`, message.channel.id)
  message.reply(`Bu özellik **Başarıyla Açıldı !** ✅  ${client.emojis.get("647746144155467786")}`)
};
exports.conf = {
  enabled: true,  
  guildOnly: false, 
  aliases: ["link-engel-aç"], 
  permLevel: 0
};

exports.help = {
  name: 'linkaç',
  description: 'sayaç', 
  usage: 'sayaç'
};
