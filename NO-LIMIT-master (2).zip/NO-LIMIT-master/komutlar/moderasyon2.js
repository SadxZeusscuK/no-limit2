const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
  if(!message.member.hasPermission('ADMINISTRATOR')) return message.reply('💢 Bu Komutu Kullanabilmek İçin `Yönetici` İznine Sahip Olmalısın ! 📛') 


 const Embed = new Discord.RichEmbed()
 .setTimestamp()
 .setAuthor("NO - LIMIT", client.user.avatarURL)
.setColor("RANDOM")
.setTitle("Moderasyon2 Komutları")
 .setURL("https://timsahtim-discord-panel.glitch.me")
 .setImage(`https://media.giphy.com/media/iE4ZyaPEQmRsYyb81D/giphy.gif`)
 .setDescription(`

renkli-rol-ayarla @üye : Her Hangi Bir Rol Etiketlediğinizde 2 Sn 1 Renk Değişir !

renkli-rol-aç : Renkli Rol Sistemini Aktif Etmiş Olursunuz !

renkli-rol-kapat : Renkli Rol Sistemini Kapatmış Olursunuz !

resetk : Bütün Kanalları Siler !

resetr : Bütün Rolleri Siler !

rolbilgi : Her Hangi Bakmak İstediğin Roldeki Bütün Bilgilerini Size Verir !

sa-as : Selamun Aleyküm  -  Aleyküm Selam Sistemini Açarsınız !

sil : İstediğiniz Kanaldaki Mesajları Silersiniz !

sunucu-bilgi : Sunucunun Bütün Bilgilerini Size Verir !

sunucu-panel : Sunucu Panel Ayarlar !

sunucu-resmi : Sunucunun Resmini Size Paylaşır !

seviye-aç : Seviye Sistemini Aktif Etmiş Olursunuz !
 
seviye-xp : Seviye Xp'sini Ayarlarsınız !

seviye-log : Seviye Log Kanalını Ayarlarsınız !

seviye-rol : Seviye Karşılığı Ödül Olarak Rol Verirsiniz !

seviye : Seviyenize Bakarsınız !

seviye-kapat : Seviye Sistemini Kapatırsınız !

yavaş-mod : HerHangi Ayarladığınız Kanalda Belirlediğiniz Sürede Bir Yazabilirler !

yaz : NO - LIMIT Adlı Bot Üzerinden Yazarsınız !

özel-oda-sistemi : Özel Oda Sistemi Kurarsınız !

özelhg : Sunucuya Katılana Belirlediğiniz Mesajı Gönderir !

özelbb : Sunucudan Ayrılana Belirlediğiniz Mesajı Gönderir !

üyedurum : Her Hangi Bir Kullanıcının Durumunu Gösterir !



NO - LIMIT | "Botumuz Sizin İsteklerinizle Güzelleşiyor !"
`)
 .setFooter("NO - LIMIT", client.user.avatarURL)
 message.channel.send(Embed).then(msg => msg.delete(13000));
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["yardım-moderasyon2","help-moderation2","hm2","help-moderation2"],
  permLevel: 0
};

module.exports.help = {
  name: 'yardım-moderasyon2',
  description: 'Moderasyon2 Menüsünü Gösterir.',
  usage: 'yardım-moderasyon2'
};
