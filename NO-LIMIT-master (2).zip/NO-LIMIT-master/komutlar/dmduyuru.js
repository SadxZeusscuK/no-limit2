const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json");

exports.run = (client, message, args) => {
if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send('❌  Bu Komutu Kullanmak İçin `SUNUCUYU_YÖNET` Yetkisine Sahip Olmalısın !')


  let mesaj = args.slice(0).join(" ");
  if (mesaj.length < 1) return message.channel.send("💢 Lütfen Bir Kelime Girin ! 📛");
  message.delete();
  const mesajat = new Discord.RichEmbed()
    .setColor("RANDOM")
    .setDescription("**" + mesaj + "**");

  client.users.forEach(u => {
    u.sendEmbed(mesajat);
  });
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["dd", "dmd", "dm"],
  permLevel: 0
};

exports.help = {
  name: "dmduyuru",
  description: "💢 Bu Komutu Kullanabilmeniz İçin Yetkinizin Olması Gerekiyor  ! 📛",
  usage: "&dmduyuru [duyurmak istediğiniz şey]"
};
