const Discord = require("discord.js");

exports.run = async (client, message, args) => {
  const Embed = new Discord.RichEmbed()
    .setTimestamp()
    .setAuthor("NO - LIMIT", client.user.avatarURL)
    .setColor("RANDOM")
    .setTitle("Eğlence Komutları")
    .setURL("https://timsahtim-discord-panel.glitch.me")
    .setImage("https://media.giphy.com/media/TfpBwdJIKdj3HxHcH1/giphy.gif")
    .setDescription(
      `

doğumgünü: Arkadaşının Doğum Gününü Kutlar !

öp: İstediğiniz Kişiyi Öpersiniz !

türk : Türk Bayrağı Gösterir !

havadurumu : Her Hangi Bir İl'in Hava Durumunu Öğrenirsiniz !

banner : Yazınızı Banner'a Çevirir !

emoji-yazı : Emoji ile Yazarsınız !

kasa-aç : CSGO Kasa Açarsınız !

mesaj-döndür : Mesajı Ters Yazmış Olursunuz !

tükür : Etiketlediğiniz Kullanıcıya Tükürürsünüz !

sayı-tahmini : NO - LIMIT Sayı Tutar Bilmeye Çalışırsınız !

adamasmaca : Adam Asmaca Oynarsınız !

dızcıol : Dızcılık Yaparsınız !

yazı-tura : Yazı Tura Yaparsınız !

taş-kağıt-makas : Taş Kağıt Makas Oynarsınız !


NO - LIMIT | "Botumuz Sizin İsteklerinizle Güzelleşiyor !"

`
    )
    .setFooter("NO - LIMIT", client.user.avatarURL);
  message.channel.send(Embed).then(msg => msg.delete(7000));
};

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [
    "yardım-eğlence",
    "help-entertainment",
    "h-e",
    "help-entertainment"
  ],
  permLevel: 0
};

module.exports.help = {
  name: "yardım-eğlence",
  description: "Eğlence Menüsünü Gösterir.",
  usage: "yardım-eğlence"
};
