const Discord = require('discord.js');

exports.run = function(client, message, args) {
    if(message.channel.type == "dm")  return;
  if(message.channel.type !== "text") return;
  if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`Bu Komutu Kullanabilmek İçin "**Yönetici**" Yetkisine Sahip Olmalısın ! 📛`);
  let guild = message.guild
  let [link, ad] = args.join(" ").split(" - ");
  if (!link) return message.channel.send(`**Bir Bağlantı Girmen Gerekli !**   🌐`)
  if (!ad) return message.channel.send(`**Bir İsim Yazman Gerekli !** 🌐.`)
  
  guild.createEmoji(link, ad)
    .then(emoji => message.channel.send(`${emoji.name} **Adında Emoji Başarıyla Oluşturuldu !** ✅ (${emoji})`))
    .catch(console.error);
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['emoji-ekle','emojiekle','emoji-yükle'],
  permLevel: 3
};

exports.help = {
  name: 'emojiyükle',
  description: 'Belirttiğiniz link ve isimde emoji yükler.',
  usage: 'emojiyükle <link> - <isim>'
};
