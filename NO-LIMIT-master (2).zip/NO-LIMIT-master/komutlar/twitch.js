  
const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {



    let twitch = args.slice(0).join('+');

        let link = `https://www.twitch.tv/search?term=` + twitch;
        if(!twitch)return message.reply(`🛑 Lütfen Bir Yayıncı Adı Girin ! 💢`)
        if(!link)return message.reply("Console error")
        let embed = new Discord.RichEmbed()
 
         
     .setColor("BLUE")
         
          .setTimestamp()
        
          .addField('Aktivasyon:', '💠 Twitch da Aranıyor ! ')

          .addField("Aranan:", `${args.slice(0).join(' ')}`)

          .addField('Link:', `${link}`)
         
          .setFooter("Avatarın", message.author.avatarURL);
          
              
              message.author.send(`**💻 Aradığın Bağlantı Başarıyla Bulundu ! ✅** ${link} - - - Komutu Girdiğin Sunucu: ${ message.guild.name}`);

        
    
}



exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'twitch',
  description: 'Tüm Komutları Listeler .  İsterseniz Bir Komut Hakkında Yardım Eder..',
  usage: 'twitch'
};
