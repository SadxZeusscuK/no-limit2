  const Discord = require("discord.js");

exports.run = async (bot, message, args) => {

    let sonuc = ["`1 Cm`\nƐ=>  \Ölçmek ve Bakmaya Gerek Yok :joy:","`2 Cm`\nƐ==>  \Bu Ne La :joy:","`3 Cm`\nƐ===>  \Ay Yazık :joy:","`4 Cm`\nƐ====>  \Taştan Bile Küçük :joy:","`5 Cm`\nƐ=====>  \Anlatmaya Gerek Yok Görüyorsunuz İşte :joy:","`6 Cm`\nƐ======>  \Taştan Azcık Büyük :joy:","`7 Cm`\nƐ=======>  \Ahlatacak Kadar Güç Bile Yok :joy:","`8 Cm`\nƐ========>  \Sızıntı Yapıyor :joy:","`9 Cm`\nƐ=========>  \Durumun Belli :joy:","`10 Cm`\nƐ==========>  \Eh İşte :joy:","`11 Cm`\nƐ===========>  \Oooo Sen Büyütmeyi Biliyormuydun :joy:","`12 Cm`\nƐ============>  \En Azından Kız Sikerken Zıplatabilirsin :joy:","`13 Cm`\nƐ=============>  \Yıldız Gibi Parlamaya Başladı :joy:","`14 Cm`\nƐ==============>  \Zevk Suları Akmaya Başlasın :joy:","`15 Cm`\nƐ================>  \Önüne Geleni Garanti Ahlatırsın ! :joy:","`16 Cm`\nƐ================>  \Knk Yarrağı Pantolona Nasıl Sığdırıyorsun :joy:","`17 Cm`\nƐ=================>  \Demir Gibi Maşallah :joy:","`18 Cm`\nƐ==================>  \Motor Deliyor Artık :joy:","`19 Cm`\nƐ===================>  \Artık Motor Değil Uçak Oldu Milleti Taşıyor :joy:","`20 Cm`\nƐ====================>  \Makinaya Bak Yarmaya Başlamış  :joy:","`21 Cm`\nƐ=====================>  \Ooooowwww  Ağlatmaya Başlamışın  :joy:","`22 Cm`\nƐ======================>  \Yok Artık İnsaflı Ol Kızı Delme :joy:","`23 Cm`\nƐ=======================>  \Kırılma Boyutundan Çıktı :joy:","`24 Cm`\nƐ========================>  \Taş Gibi Taş :joy:","`25 Cm`\nƐ=======================>  \Artık Ölçecek Cetvel Kalmadı  :joy:","`26 Cm`\nƐ=========================>  \Yok Artık Amk Dış Savaşlarda Artık Senin Yarrağın Kullanılır :joy:","`27 Cm`\nƐ=========================================>  \Kızların Senin Yarrağına Dediği Cümleler : Yok Artık AmınaKoyayım Ne Güzel Bir Malataf Sok Götüme OHHHH :joy:","`28 Cm`\nƐ====>  \Bu Ne La :joy:","`29 Cm`\nƐ====>  \Bu Ne La :joy:","`30 Cm`\nƐ=================================================>  \Uçak Bekliyordun . Ama Senin Uçağın Gidip Kadının Amına Uçtu ! :joy:","`31 Cm`\nƐ==============================>  \Sayın Yolcularımız 31 Nolu Uçağımız Havalimanından Kalkmaktadır ! :joy:","`8 Cm`\nƐ====>  \Bu Ne La :joy:","`8 Cm`\nƐ====>  \Bu Ne La :joy:","`8 Cm`\nƐ====>  \Bu Ne La :joy:","`8 Cm`\nƐ====>  \Bu Ne La :joy:","`8 Cm`\nƐ====>  \Bu Ne La :joy:","`8 Cm`\nƐ====>  \Bu Ne La :joy:", "``19CM``\nƐ=============>  \n40 Yıldır Kampçıyım Böyle Çadır Görmedim :joy:", "``20CM``\nƐ=============>  \nPantolona Nasıl Sığdırıyorsun Amq :joy:", "`21CM`\nƐ=============>  \Yuh Amq Kadına Yazık Olacak :joy:"];

    let result = Math.floor((Math.random() * sonuc.length));

    let kacembed = new Discord.RichEmbed()
    .setAuthor(message.author.username)
    .setThumbnail(message.author.avatarURL)
    .setColor('RANDOM')
    .setFooter(`${bot.user.username} `, bot.user.avatarURL)
    .addField("Malataf Diyecek Laf Yok !", sonuc[result]);
    

    message.channel.send(kacembed);
}

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['malafat', 'kaçcm'],
    permLevel: 0
  };
  
  exports.help = {
    name: 'kaç-cm',
    description: 'kac-cm',
    usage: 'kaç-cm'
  };
