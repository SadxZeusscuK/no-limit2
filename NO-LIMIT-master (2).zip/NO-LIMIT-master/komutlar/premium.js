const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');




exports.run = (client, message, args) => {
    const embed = new Discord.RichEmbed()
        
        .setTitle(`${client.user.username} PREMİUM SİSTEMİ `)
        .setDescription(`[Premium Kısa Süre İçinde Aktif Olacaktır !](https://no-limit-web-panel.glitch.me)`)
        .setThumbnail(client.user.avatarURL)
        .setFooter(`${message.author.username} Başarıyla ${ayarlar.prefix}Premium Sistemini Kullandı !`, message.author.avatarURL)
        .setImage("https://media.giphy.com/media/j6BkfRGIpjPtnXC5N1/giphy.gif") 
    .setColor(`RANDOM`)
    return message.channel.sendEmbed(embed);
  

};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: 'premium',
  description: '',
  usage: 'premium'
};
