const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');




exports.run = (client, message, args) => {
    const embed = new Discord.RichEmbed()
        
        .setTitle(`${client.user.username} DAVET SİSTEMİ `)
        .setDescription(`[NO - LIMIT](https://discord.com/oauth2/authorize?client_id=717386782819352647&scope=bot&permissions=2146958847)**|** [NO - MUSIC](https://discord.com/oauth2/authorize?client_id=723525016414584832&scope=bot&permissions=805314622)`)
        .setThumbnail(client.user.avatarURL)
        .setFooter(`${message.author.username} Başarıyla ${ayarlar.prefix}Davet Sistemini Kullandı !`, message.author.avatarURL)
        .setImage("https://media.giphy.com/media/TfpBwdJIKdj3HxHcH1/giphy.gif") 
    .setColor(`RANDOM`)
    return message.channel.sendEmbed(embed);
  

};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["davet","invite"],
  permLevel: 0,
};

exports.help = {
  name: 'davet',
  description: '',
  usage: 'davet'
};
