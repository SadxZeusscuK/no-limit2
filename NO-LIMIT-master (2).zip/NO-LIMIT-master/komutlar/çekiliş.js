const Discord = require("discord.js");
module.exports.run = async (bot, message, args) => {

let draw = args.join(" ").slice(0);
let user = message.author.username;
let guild = message.guild.name;
let guildid = message.guild.id;
let kanal = message.channel.name;
let channel = bot.channels.get("700647586494939207")//çekiliş başvuru kanal id'i
let embed = new Discord.RichEmbed()
.setTitle("Çekiliş Başvuru")
.setThumbnail("https://cdn.discordapp.com/attachments/722474087045398559/723117947278589972/NO_-_LIMIT.png")
.addField("çekiliş", draw)
.addField("Çekiliş Başvurusu Yapan", user, true)
.addField("Sunucu", guild, true)
.addField("Sunucu ID", guildid, true)
.addField("Kanal", kanal, true)
.setColor("#f49542")

message.channel.send("**🎉 Çekilişe Başarıyla Katıldınız ! ✅**")
channel.send(embed).then(i => i.react("⏳"))

  


}
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0  
};

exports.help = {
  name: 'aktif olmayan komut2',
  description: 'Ücretsiz Çekilişten Hediyeler Kazanırsınız !',
  usage: 'aktif olmayan komut2'
}
