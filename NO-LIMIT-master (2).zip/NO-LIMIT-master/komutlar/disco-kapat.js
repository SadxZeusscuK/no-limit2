const Discord = require("discord.js");
const db = require("quick.db");

exports.run = async (client, msg, args) => {
  if (!msg.member.hasPermission("ADMINISTRATOR"))
    return msg.reply(
      `💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmasın ! 📛`
    );

  let RenkliR = await db.delete(`discorol_${msg.guild.id}`);
  setInterval(() => {
    msg.guild.roles.find("name", RenkliR).setColor("RANDOM");
  }, 3000);
  msg.channel.send(
    `⚡ Renkli Rol Özelliği Kapatıldı ! ⚡`
  );
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["renkli-rol-kapat"],
  permLevel: 3
};

exports.help = {
  name: "renkli-rol-kapat",
  description: "Disco",
  usage: "renkli-rol-kapat"
};
