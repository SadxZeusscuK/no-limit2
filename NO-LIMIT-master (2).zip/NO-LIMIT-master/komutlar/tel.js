const Discord = require("discord.js");

exports.run = async (bot, message, args) => {

    let sonuc = ["`0555 031 86 36`\ Hadi Beklemeden Ara !","`0530 071 30 34`\ Hadi Beklemeden Ara !","`0530 015 93 78`\ Hadi Beklemeden Ara !","`0505 017 54 03`\ Hadi Beklemeden Ara !","`0551 398 42 18`\ Hadi Beklemeden Ara !","`0536 256 67 16`\ Hadi Beklemeden Ara !","`0542 848 38 49`\ Hadi Beklemeden Ara !","`0537 795 98 98`\ Hadi Beklemeden Ara !","`0535 783 59 54`\ Hadi Beklemeden Ara !","`0542 896 10 70`\ Hadi Beklemeden Ara !","`0536 591 05 28`\ Hadi Beklemeden Ara !","`0537 796 21 52`\ Hadi Beklemeden Ara !","`0551 398 42 18`\ Hadi Beklemeden Ara !","`0554 171 66 69`\ Hadi Beklemeden Ara !","`0507 900 59 70`\ Hadi Beklemeden Ara !","`0535 551 38 08`\ Hadi Beklemeden Ara !","`0536 591 05 28`\ Hadi Beklemeden Ara !","`0536 479 08 06`\ Hadi Beklemeden Ara !","`0537 614 12 38`\ Hadi Beklemeden Ara !","`0537 614 12 38`\ Hadi Beklemeden Ara !","`0539 451 54 87`\ Hadi Beklemeden Ara !","`0506 102 31 87`\ Hadi Beklemeden Ara !","`0539 941 36 94`\ Hadi Beklemeden Ara !","`0536 342 88 52`\ Hadi Beklemeden Ara !","`0535 637 63 00`\ Hadi Beklemeden Ara !","`0554 168 29 05`\ Hadi Beklemeden Ara !","`0536 342 88 52`\ Hadi Beklemeden Ara !","`0537 237 88 70`\ Hadi Beklemeden Ara !","`0543 243 72 68`\ Hadi Beklemeden Ara !","`0538 412 10 71`\ Hadi Beklemeden Ara !","`0537 237 88 70`\ Hadi Beklemeden Ara !","`0554 171 66 69`\ Hadi Beklemeden Ara !","`0537 035 41 19`\ Hadi Beklemeden Ara !","`0542 896 10 70`\ Hadi Beklemeden Ara !","`0539 560 82 49`\ Hadi Beklemeden Ara !","`0537 474 88 97`\ Hadi Beklemeden Ara !","`0536 591 05 28`\ Hadi Beklemeden Ara !","`0542 896 10 70`\ Hadi Beklemeden Ara !","`0506 102 31 87`\ Hadi Beklemeden Ara !","`0537 035 41 19`\ Hadi Beklemeden Ara !","`0535 551 38 08`\ Hadi Beklemeden Ara !"];

    let result = Math.floor((Math.random() * sonuc.length));

    let kacembed = new Discord.RichEmbed()
    .setAuthor(message.author.username)
    .setThumbnail(message.author.avatarURL)
    .setColor('RANDOM')
    .setFooter(`${bot.user.username} `, bot.user.avatarURL)
    .addField("Kız Telefon Numarası", sonuc[result]);
    

    message.channel.send(kacembed);
}

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['telefon', 'phone'],
    permLevel: 0
  };
  
  exports.help = {
    name: 'tel',
    description: 'telefon phone',
    usage: 'tel'
  };
