const Discord = require('discord.js')

exports.run = (client, message, args) => {
  let user = message.mentions.users.first();
  if(!user) return message.channel.send('Öpüceğin Kullanıcıyı Etiketlemen Gerekli !')
  if (user.id === message.author.id) return message.reply('Kendini Emcükleyemessin Olum Sakin Ol ! 😂');

    
  if ( message.react('💞')) {
      var gif = [
      'https://cdn.discordapp.com/attachments/700648333877837875/724883406969634827/tumblr_458e67583de161f9e0852c6419a9e39b_01a47aae_500.gif', 'https://cdn.discordapp.com/attachments/700648333877837875/724883711241355304/s-0493058879481b5d06ca5ce45854401692993dd3.gif', 'https://cdn.discordapp.com/attachments/700648333877837875/724883602239651840/opusme-sevgi-seksi-animasyon-whatsapp3.gif', 'https://cdn.discordapp.com/attachments/700648333877837875/724883546610860102/tumblr_inline_ne88o7O8fI1ro4tlc.gif', 'https://cdn.discordapp.com/attachments/700648333877837875/724883465258008607/giphy.gif', 'https://cdn.discordapp.com/attachments/700648333877837875/724883543251091486/77086e5e4c540462b237a1c05be80a7b.gif', 'https://cdn.discordapp.com/attachments/700648333877837875/724883420357984377/710b4ef81d8302b92a58e0e400210328.gif'];

      var gifler = gif[Math.floor(Math.random() * gif.length)];
  }
    
    if (message.react('💞')) {
    const op = new Discord.RichEmbed()
    .setDescription(`<@${message.author.id}>` + ` <@${user.id}>'ı öptü <3`)
    .setColor('RED')
    .setImage(gifler)
    return message.channel.send(op)
    }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'öp',
  description: 'öp',
  usage: 'öp'
};
