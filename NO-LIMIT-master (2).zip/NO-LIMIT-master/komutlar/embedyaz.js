const Discord = require('discord.js')
const { RichEmbed } = require('discord.js')
exports.run = (client, message, args) => {

  let yazıiçeriği = args.slice().join(' ')
  const Mesaj = new RichEmbed()
    .setColor('RANDOM')
    .setDescription(yazıiçeriği)

message.channel.send(Mesaj)
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['embed', 'embedyazı'],
  permLevel: 0
}

exports.help = {
  name: 'embedyaz'
}
