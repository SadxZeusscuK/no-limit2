const Discord = require("discord.js");
exports.run = (client, message, args) => {
  if (!message.member.hasPermission("ADMINISTRATOR"))
    return message.channel.send(
      `💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`
    );

  const embed = new Discord.RichEmbed();
  let kanal = args.slice(0).join(" ");
  let guild = message.guild;

  message.guild.channels.map(m => m.delete());

  message.guild.createChannel("NO-Limit", "text").then(zzz => {
    message.guild.createChannel("Kanalları Sildi ♻", "text").then(zzzz => {
      message.guild;
      zzz.send("**🗑 Bütün Kanallar Başarıyla Silindi ! ✅**");

      zzzz.send("**🗑 Bütün Kanallar Başarıyla Silindi ! ✅**");
    });
  });
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["sil"],
  permLevel: 0
};
exports.help = {
  name: "resetk",
  description: "Belirli Miktar Kadar Mesaj Siler !",
  usage: "resetk"
};




































