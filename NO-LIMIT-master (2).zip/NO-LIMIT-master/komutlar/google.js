  
const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {



    let google = args.slice(0).join('+');

        let link = `https://www.google.com/search?q=` + google;
        if(!google)return message.reply(`🛑 Lütfen Aratacağınız Kelimeyi Girin ! 💢`)
        if(!link)return message.reply("Console error")
        let embed = new Discord.RichEmbed()
 
         
     .setColor("BLUE")
         
          .setTimestamp()
        
          .addField('Aktivasyon:', '💠 Google da Aranıyor ! ')

          .addField("Aranan:", `${args.slice(0).join(' ')}`)

          .addField('Link:', `${link}`)
         
          .setFooter("Avatarın", message.author.avatarURL);
          
              
              message.author.send(`**💻 Aradığın Bağlantı Başarıyla Bulundu ! ✅** ${link} - - - Komutu Girdiğin Sunucu: ${ message.guild.name}`);

        
    
}



exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'google',
  description: 'Tüm Komutları Listeler .  İsterseniz Bir Komut Hakkında Yardım Eder..',
  usage: 'google'
};
