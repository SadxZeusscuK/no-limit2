const Discord = require('discord.js');

exports.run = (client, message, args) => {
 if(!message.member.hasPermission('MANAGE_CHANNELS')) return message.reply('💢 Bu Komutu Kullanabilmek İçin `Mesajları_Yönet` İznine Sahip Olmalısın ! 📛')

  let mesaj = args.slice(0).join(' ');
if (mesaj.length < 1) return message.reply(' 💬 Yazmam İçin Herhangi Bir Kelime Yazmalısın !');
  message.delete();
  message.channel.send(mesaj);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['say', 'söyle'],
  permLevel: 0
};

exports.help = {
  name: 'yaz',
  description: 'İstediğiniz şeyi bota yazdırır.',
  usage: 'yaz [yazdırmak istediğiniz şey]'
};
