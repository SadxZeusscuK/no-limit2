const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
  if(!message.member.hasPermission('ADMINISTRATOR')) return message.reply('💢 Bu Komutu Kullanabilmek İçin `Yönetici` İznine Sahip Olmalısın ! 📛')


 const Embed = new Discord.RichEmbed()
 .setTimestamp()
 .setAuthor("NO - LIMIT", client.user.avatarURL)
.setColor("RANDOM")
.setTitle("Moderasyon Komutları")
 .setURL("https://timsahtim-discord-panel.glitch.me")
 .setImage(`https://media.giphy.com/media/iE4ZyaPEQmRsYyb81D/giphy.gif`)
 .setDescription(`

ban : Kullanıcıyı Sunucudan Banlarsınız !

davetoluştur : Sunucuya Kullanıcı Gelmesi İçin Davet Oluşturur !

dmduyuru : Sunucudaki Herkese NO - LIMIT Özelden Duyuru Atar !

duyurukanal : Duyuru Kanalını Ayarlarsınız !

duyuru : Duyuru Kanalında Duyuru Yaparsınız !

emoji-yükle : Sunucuya Emoji Eklersiniz !

güvenlik : Güvenlik Kanalında Şüphelileri Gösterir !

istatistik : NO - LIMIT Adlı Botun İstatistiklerine Bakar !

kanal-kilit : Olduğunuz Kanalı Belirlediğiniz Süre Kilitler !

küfüraç : Küfür Filtresini Açarsınız Ayarladığınız Kanalda Kimse Küfür Edemez !

küfürkapat : Küfür Filtresini Kapatırsınız !

linkaç : Bağlantı Filtresini Açarsınız Bu Sayede Kimse Reklam Linkleri veya Başka Durumları Göremezler !

linkkapat : Bağlantı Filtresini Kapatırsınız !

metin-kanal-aç : Hiç Uğraşmadan Hızlı Bir Şekilde Metin Kanalı Açarsınız !

ses-kanal-aç : Hiç Uğraşmadan Hızlı Bir Şekilde Ses Kanalı Açarsınız !

mute : Kullanıcıyı Belirli Süre Susturursunuz !

otorol : Sunucuya Yeni Katılan Kullanıcılara Belirlediğiniz Rol Verilir !

ping : NO - LIMIT Adlı Botun Pingine Bakarsınız !

reboot : NO - LIMIT Adlı Botu Yeniden Başlatırsınız !



NO - LIMIT | "Botumuz Sizin İsteklerinizle Güzelleşiyor !"
`)
 .setFooter("NO - LIMIT", client.user.avatarURL)
 message.channel.send(Embed).then(msg => msg.delete(15000));
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["yardım-moderasyon","help-moderation","hm","help-moderation"],
  permLevel: 0
};

module.exports.help = {
  name: 'yardım-moderasyon',
  description: 'Moderasyon Menüsünü Gösterir.',
  usage: 'yardım-moderasyon'
};
