const Discord = require("discord.js");
const db = require("quick.db");

exports.run = async (client, message, args) => {
  if (!message.member.hasPermission("ADMINISTRATOR"))
    return message.channel.send(
      `💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`
    );

  let RenkliRol = message.mentions.roles.first();

  if (!RenkliRol) {
    return message.channel.send(
      `⚡ Renkli Rol Özelliği Ayarlamak İstediğin Rolü Etiketlemelisin !`
    );
  }

  db.set(`discorol_${message.guild.id}`, RenkliRol.name);

  message.channel.send(`⚡ Renkli Rol \`${RenkliRol.name}\` Olarak Başarıyla Ayarlandı ! ✅`);
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["renkli-rol-ayarla"],
  kategori: "ayarlar",
  permLevel: 0
};

exports.help = {
  name: "renkli-rol-ayarla",
  description: "Disco Rolünü Ayarlar.",
  usage: "renkli-rol-ayarla <@rol>"
};
