const Discord = require('discord.js');
exports.run = (client, message, args) => {
 if(!message.member.hasPermission('ADMINISTRATOR')) return message.reply('💢 Bu Komutu Kullanabilmek İçin `Yönetici` İznine Sahip Olmalısın ! 📛')
  
  if (!message.guild) {
  const ozelmesajuyari = new Discord.RichEmbed()
  .setColor(0xFF0000)
  .setTimestamp()
  .setAuthor(message.author.username, message.author.avatarURL)
  .addField('⚠ Uyarı ⚠', 'Bu  Komutu Özel Mesajlarda kullanamazsın ! 📛');
  return message.author.sendEmbed(ozelmesajuyari); }
  let guild = message.guild;
  let reason = args.slice(1).join(' ');
  let user = message.mentions.users.first();
  if (reason.length < 1) return message.reply('Etiketlediğin Kullanıcıya Ne Göndericeğimi Yazarmısın ! 📛');
  if (message.mentions.users.size < 1) return message.reply('Etiketlediğin Kullanıcıya Ne Göndericeğimi Yazarmısın ! 📛').catch(console.error);
  message.delete();
  message.reply('Yönetici Mesajını Başarıyla Gönderdim ! ✅')
  const embed = new Discord.RichEmbed()
  .setColor('RANDOM')
  .setTitle(`**💬 Sunucu Yöneticisinden Sana Bir Mesaj Var ! 🔔**`)
  .setTimestamp()
  .setDescription(reason);
  return user.send(embed);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['pm','öm'],
  permlevel: 4
};

exports.help = {
  name: 'mesajat',
  description: 'Bir üyeye özel mesaj yollar.',
  usage: 'mesajat'
};
