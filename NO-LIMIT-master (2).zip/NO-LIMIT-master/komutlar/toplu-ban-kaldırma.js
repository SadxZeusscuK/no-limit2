const Discord = require("discord.js");
exports.run = async function(client, message, args) {

if(!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send(`💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`)
  let yasak = await message.guild.fetchBans();
  yasak = yasak.array(); 
  yasak.forEach(function(ban) {
    message.guild.unban(ban.id);

        message.channel.send(`${yasak} Adlı Tüm Kullanıcıların Yasağı Kalktı !`);

  });
            
   
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ['toplu-ban-kaldır'],
  permLevel: 2
};

exports.help = {
  name: 'toplu-ban-kaldır',
  description: 'banlıların yasaklarını kaldırır',
  usage: 'toplu-ban-kaldır'
};
