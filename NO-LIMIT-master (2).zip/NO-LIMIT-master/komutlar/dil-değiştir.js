const Discord = require("discord.js"),
  db = require("quick.db");

module.exports.run = async (client, message, args) => {
  let kontrol = await db.fetch(`dil_${message.guild.id}`);
  if (kontrol == "TR_tr") {
    let dil = args[0];
    if (!dil) {
      message.channel.send(
        "__Bir Dil Belirtin ! / Diller: `TR_tr`, `EN_us`__"
      );
      return;
    }
    if (dil === "EN_us") {
      db.set(`dil_${message.guild.id}`, dil);
      message.channel.send(`__New Language Set To \`${dil}\`!__`);
    } else if (dil === "TR_tr") {
      db.set(`dil_${message.guild.id}`, dil);
      message.channel.send(`__Yeni Dil \`${dil}\` Olarak Ayarlandı !__`);
    } else {
      message.channel.send("__Hatalı dil! Diller: `TR_tr`, `EN_us`__");
      return;
    }
  } else {
    let dil = args[0];
    if (!dil) {
      message.channel.send(
        "__Specify a Language ! / Languages: `TR_tr`, `EN_us`__"
      );
      return;
    }
    if (dil === "EN_us") {
      db.set(`dil_${message.guild.id}`, dil);
      message.channel.send(`__New Language Set To \`${dil}\`!__`);
    } else if (dil === "TR_tr") {
      db.set(`dil_${message.guild.id}`, dil);
      message.channel.send(`__Yeni Dil \`${dil}\` Olarak Ayarlandı !__`);
    } else {
      message.channel.send(
        "__Incorrect Language ! / Languages: `TR_tr`, `EN_us`__"
      );
      return;
    }
  }
};

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["language", "lang"],
  permLevel: 3
};

exports.help = {
  name: "dil-değiştir",
  description: "dil",
  usage: "dil-değiştir"
};
