const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

exports.run = (client, message, params) => {
    const embed = new Discord.RichEmbed()
        .setColor(0x00ffff)
        .setTitle("NO - LIMIT - YAPIMCILAR")
        .setThumbnail("https://cdn.pbrd.co/images/HRdm5QI.jpg") 
        .addField("**Yapımcılar**", `DangerK™ - AhmetK™ - ZeusscuK™`)
        .addField("**Denetimciler**", `DangerK™ - AhmetK™ - ZeusscuK™`)
        .addField("**Discord Hesapları**", `DangerK#9999 |--| AhmetK#4216 |--| ⤰ZeusscuK#0666`)
        .addField(`TimsahTim İnstagram`, `[TIKLA](https://www.instagram.com/dangerk.2020)`)
        .addField(`TimsahTim Discord`, `https://discord.gg/DcgNSCe`)
        .addField(`DangerK YouTube`, `[TIKLA](https://www.youtube.com/channel/UC_vrCqGrljsmu-ybnZYJZpg)`)
        .addField(`DangerK İnstagram`, `[TIKLA](https://www.instagram.com/sqlih.exe)`)
        .addField(`AhmetK İnstagram`, `[TIKLA](https://www.instagram.com/market.timsahtim/)`)
        .addField(`ZeusscuK İnstagram`, `[TIKLA](https://www.instagram.com/dangerk.2020)`)
        .setImage(`https://media.giphy.com/media/TfpBwdJIKdj3HxHcH1/giphy.gif`)
    return message.channel.sendEmbed(embed);
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['yapımcımcılarım','sahiplerim'],
    permLevel: 0
};

exports.help = {
    name: 'yapımcılar',
    description: 'Botun Yapımcısını Gösterir',
    usage: 'yapımcılar'
};
