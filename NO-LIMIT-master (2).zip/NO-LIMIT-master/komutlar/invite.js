exports.run = async(client, message, args) => {//NO - LIMIT
  let user = message.mentions.users.first() || message.author;
  if(!user) return message.channel.send("Bir Kullanıcı Etiketlemelisin !")
 let invites = await message.guild.fetchInvites() 
  let regular = invites.array().find(invite => invite.inviter.id === user.id) ? invites.find(invite => invite.inviter.id === user.id).uses : 0

message.channel.send(`Toplam **${regular}** Daveti Var !`) 
//NO - LIMIT
};
exports.conf = {
  aliases: []//NO - LIMIT
}
exports.help = {
  name: "davetlerim"
}
