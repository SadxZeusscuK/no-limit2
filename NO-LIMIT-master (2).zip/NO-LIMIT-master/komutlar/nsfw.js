const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
 
 const Embed = new Discord.RichEmbed()
 .setTimestamp()
 .setAuthor("NO - LIMIT", client.user.avatarURL)
.setColor("RANDOM")
.setTitle("Nsfw Komutları")
 .setURL("https://timsahtim-discord-panel.glitch.me")
 .setImage(`https://media.giphy.com/media/fYe0Sw3neH6b9K5x7y/giphy.gif`)
 .setDescription(`

kaçcm : Yarrağınızı Ölçer !

porn : Porno Videolarının Bağlantılarını Paylaşır ! ( Bakımda )

tel : Orospu Olmayan İnternetten Bulunan Kız Telefon Numaraları !

sosmed : Bir Sürü Kız Sosyal Medyasını Sizlere Paylaşır ! ( Bakımda )

iç : Etiketlediğiniz Kullanıcı İle İçki veya Sigara İçersiniz !

sik : Etiketlediğiniz Kullanıcıyı Sikersiniz !

ağlat : Etiketlediğiniz Kullanıcıyı Ağlatırsınız ! ( Bakımda )


NO - LIMIT | "Botumuz Sizin İsteklerinizle Güzelleşiyor !"

`)
 .setFooter("NO - LIMIT", client.user.avatarURL)
 message.channel.send(Embed)
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["yardım-nsfw","help-nsfw","h-n","help-nsfw"],
  permLevel: 0
};

module.exports.help = {
  name: 'yardım-nsfw',
  description: 'Nsfw Menüsünü Gösterir.',
  usage: 'yardım-nsfw'
};
