const Discord = require('discord.js')
const db = require('quick.db');
const ayarlar = require('../ayarlar.json')

exports.run = async (client, message, args) => {
  
  let prefix = await require('quick.db').fetch(`prefix_${message.guild.id}`) || ayarlar.prefix
 
  if (!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(`💢 Bu Komutu Kullanabilmek İçin "\`Sunucuyu Yönet\`" Yetkisine Sahip Olmalısın ! 📛`);
  
  let mesaj = args.slice(0).join(' ')
  
      if (!mesaj) {
        return message.channel.send(`Özel Hoşgeldin Mesajını Yazmalısın ! \`${prefix}özelhoşgeldin -sunucu- Sunucusuna Hoşgeldin -kullanıcı- !\``)
    }
  
    db.set(`ozelhosgeldin_${message.guild.id}`, mesaj)
    message.channel.send(` Özel Hoşgeldin Mesajı \`${mesaj}\` Olarak Başarıyla Ayarlandı ! ✅`)
}
    
exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: [],
    permLevel: 0
}

exports.help = {
    name: 'özel-hoşgeldin-ayarla',
    description: 'Sunucuya giren kişiye özelden gönderilecek mesajı ayarlar. (Kullanıcı isminin geleceği yere "-kullanıcı-", sunucu isminin geleceği yere "-sunucu-" yazınız.)',
    usage: 'özelhoşgeldin <yazı>'
}
