const Discord = require('discord.js');
exports.run = function(client, message, args) {
if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("**💢   Bu   Komutu   Kullanmak   İçin   /`Mesajları Yönet`/   Yetkisine   Sahip   Olmalısın !   📛**").then(msg => msg.delete(5000));

if(!args[0]) return message.channel.send("**💬  En  Az  1 - 100   Arasında   Bir   Tam   Sayı   Değeri   Girmelisiniz  !   🗑**").then(msg => msg.delete(4000));
message.channel.bulkDelete(args[0]).then(() => {
  message.channel.send(`**🗑   ${args[0]}   Adet   Mesaj   Başarıyla   Silindi   !   ✅**`).then(msg => msg.delete(3000));
})
}

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ['sil,t,s'],
  permLevel: 2
};

exports.help = {
  name: 'sil',
  description: 'Belirlenen miktarda mesajı siler.',
  usage: 'sil <silinicek mesaj sayısı>'
};
