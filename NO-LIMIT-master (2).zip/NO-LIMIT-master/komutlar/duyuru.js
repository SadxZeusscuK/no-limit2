const Discord = require("discord.js");
const fla = require('quick.db')

exports.run = async (client, message, args) => {
if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(':no_entry:❌  Bu Komutu Kullanmak İçin `SUNUCUYU_YÖNET` Yetkisine Sahip Olmalısın !')

    let mesaj = args.join(" ");
if (!mesaj) return message.channel.send('Lütfen Duyuru\'ya Atılıcak Yazıyı Giriniz.')
  
  let kanalid = await fla.fetch(`duyuru-kanal_${message.guild.id}`)
  let kanal = client.channels.get(kanalid)

  const embed = new Discord.RichEmbed()
  .setTitle('📢 Duyuru')
  .setDescription(mesaj)
  .setColor('RANDOM')
  kanal.send(embed)
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: 'duyuru',
  description: 'Önemli Duyuru',
  usage: 'duyuru'
};
