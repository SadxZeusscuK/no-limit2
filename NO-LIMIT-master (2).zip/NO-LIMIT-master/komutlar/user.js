const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
 
 const Embed = new Discord.RichEmbed()
 .setTimestamp()
 .setAuthor("NO - LIMIT", client.user.avatarURL)
.setColor("RANDOM")
.setTitle("Kullanıcı Komutları")
 .setURL("https://timsahtim-discord-panel.glitch.me")
 .setImage(`https://media.giphy.com/media/TfpBwdJIKdj3HxHcH1/giphy.gif`)
 .setDescription(`

ailemiz : NO - LIMIT Olduğu Sunuculara Bakarsınız !

avatar : Sunucudaki Kişilerin Avatarına Bakarsınız !

bilgi : NO - LIMIT Bilgilerine Bakarsınız !

davet : NO - LIMIT Sunucunuza Davet Edersiniz !

davet-sıralaması : Sunucu Davet Sıralamasına Bakarsınız !

davetlerim : Davet Sayınıza Bakarsınız !

üyedurum : Sunucunuzun Durumuna Bakarsınız !

yasaklar : Sunucudan Yasaklanan Kişileri Gösterir !

ping : NO - LIMIT Pingine Bakarsınız !

oy-ver : NO - LIMIT  Oy Verirsiniz !

istatistik : NO - LIMIT Adlı Botun İstatistiklerine Bakarsınız !

yapımcılar : NO - LIMIT Botunu Yapan Kullanıcıları Gösterir !

havadurumu : Hava Durumuna Bakarsınız !

oylama : Oylama Yaparsınız !

game-search : Play Store Search Games !

count : Counts Users on Server and Voice Channels !


NO - LIMIT | "Botumuz Sizin İsteklerinizle Güzelleşiyor !"

`)
 .setFooter("NO - LIMIT", client.user.avatarURL)
 message.channel.send(Embed).then(msg => msg.delete(7000));
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["help-user"],
  permLevel: 0
};

module.exports.help = {
  name: 'help-user',
  description: 'Kullanıcı Menüsünü Gösterir.',
  usage: 'help-user'
};
