const Discord = require('discord.js');
exports.run = async (client, message, args) => { 
let prefix = '-'
let yardım = new Discord.RichEmbed()  
.setAuthor(`${client.user.username}`, client.user.avatarURL)
.setColor('BLUE')
.addField('NO - LIMIT | Yardım Menüsü',`

**=\`-yardım-moderasyon\` ⇝ Moderasyon Menüsü**

**=\`-yardım-moderasyon2\` ⇝ Moderasyon2 Menüsü**

**=\`-yardım-kullanıcı\` ⇝ Kullanıcı Menüsü**

**=\`-yardım-eğlence\` ⇝ Eğlence Menüsü**

**=\`-yardım-medya\` ⇝ Medya Menüsü** 

**=\`-yardım-nsfw\` ⇝ Nsfw Menüsü** `)

.setFooter(`${message.author.tag} Tarafından İstendi !`, message.author.avatarURL)
.addField('NO - LIMIT',`[Destek Sunucusu](https://discord.gg/timsahtim)  **|** [Web Panel](https://timsahtim-extra.glitch.me)`)
.setImage(`https://media.giphy.com/media/TfpBwdJIKdj3HxHcH1/giphy.gif`)
.setThumbnail(client.user.avatarURL)
 message.channel.send(yardım) 
  };
exports.conf = {
  enabled: true,  
  guildOnly: false, 
  aliases: ["help","help","yardım"], 
  permLevel: 0
};
exports.help = {
  name: 'yardım'
}; 
