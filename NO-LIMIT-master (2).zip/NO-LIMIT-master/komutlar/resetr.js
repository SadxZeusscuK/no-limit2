const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {
   if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`💢 Bu Komutu Kullanabilmek İçin "\`Yönetici\`" Yetkisine Sahip Olmalısın ! 📛`);

let mesaj = args.slice(0).join(" ")
message.guild.roles.forEach(a => a.delete())
message.guild.createRole({ name: `${mesaj}`, position: 20, permissions: ['MANAGE_MESSAGES'], color: 'RED'})
message.channel.send('**Tüm Roller Başarıyla Silindi ! ✅**')
};

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
  kategori: "sunucu"
};

module.exports.help = {
  name: "resetr",
  description: "resetr",
  usage: "resetr"
};
