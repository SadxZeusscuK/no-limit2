const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
 
 const Embed = new Discord.RichEmbed()
 .setTimestamp()
 .setAuthor("NO - LIMIT", client.user.avatarURL)
.setColor("RANDOM")
.setTitle("Sosyal Medya Komutları")
 .setURL("https://cdn.discordapp.com/attachments/640425207881924608/711105204749205544/NO_-_LIMIT.png")
 .setDescription(`


google : İstediğiniz Herşeyi Aratıp Bakabilirsiniz !  

youtube : Video - Kanal Aratıp Bakabilirsiniz !

twitch : Bir Yayıncı Aratıp Bakabilirsiniz ! 

twitter : Bir Kullanıcı Aratıp Bakabilirsiniz !

facebook : Bir Kullanıcı - Gurup Aratıp Bakabilirsiniz !

instagram : Kısa Süre Devre Dışı Bırakılmıştır !

spotify : Bir Kullanıcı Etiketleyip Onun Dinlediği Şarkıyı Dinlersiniz !

çeviri : İstediğiniz Dili Bir Dille Çevirip Anlamını Görebilirsiniz !



NO - LIMIT | "Botumuz Sizin İsteklerinizle Güzelleşiyor !"

`)
 .setFooter("NO - LIMIT", client.user.avatarURL)
 message.channel.send(Embed)
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["yardım-medya","help-media","h-m","help-media"],
  permLevel: 0
};

module.exports.help = {
  name: 'yardım-medya',
  description: 'Sosyal Medya Menüsünü Gösterir.',
  usage: 'yardım-medya'
};
