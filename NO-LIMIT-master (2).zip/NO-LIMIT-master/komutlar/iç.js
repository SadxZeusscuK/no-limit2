const Discord = require('discord.js')

exports.run = (client, message, args) => {
  
 
  if ( message.react('🚬')) {
      var gif = [
      'https://cdn.discordapp.com/attachments/691685100261343274/722177850379206720/sigara-icen-erkek_915928.gif', 'https://cdn.discordapp.com/attachments/691685100261343274/722178014372298862/Kafam_Guzel_sig.gif', 'https://cdn.discordapp.com/attachments/691685100261343274/722178491365195826/Yldz_Sig.gif','https://cdn.discordapp.com/attachments/691685100261343274/722178705463705660/Beer_Kadn.gif', 'https://cdn.discordapp.com/attachments/691685100261343274/722178735079555103/Beer_Erkek.gif'];

      var gifler = gif[Math.floor(Math.random() * gif.length)];
  }
    
    if (message.react('🚬')) {
    const ic = new Discord.RichEmbed()
    .setColor('RANDOM')
    .setImage(gifler)
    return message.channel.send(ic)
    }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'iç',
  description: 'iç',
  usage: 'iç'
};
